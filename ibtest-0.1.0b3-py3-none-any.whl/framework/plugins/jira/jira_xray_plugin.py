# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

import base64
import copy
import json
import os
import re
from typing import Optional

import requests

from framework.core.utils import get_logger
from framework.plugins.base import Plugin

from .reporter import XrayReporter

logger = get_logger()


class XrayTestKeyValidationError(ValueError):
    """Custom exception for invalid test keys."""

    pass


class XrayPlugin(Plugin):
    XRAY_BASE_URL = None
    XRAY_AUTH_URL = None
    XRAY_IMPORT_URL = None
    REQUEST_TIMEOUT = 30  # seconds
    JIRA_ID_PATTERN = re.compile(
        r"^[A-Z0-9]+-\d+$"
    )  # Regex to validate Jira ID format (e.g., MYS-123)

    def __init__(self, config):
        self.logger = get_logger()
        self.config = config
        self.xray_cfg = {}
        reporting_cfg = self.config.get("reporting", [])
        if reporting_cfg:
            for entry in reporting_cfg:
                if entry.get("name") == "XrayPlugin":
                    self.xray_cfg = entry.get("config", {})
                    if self.xray_cfg:
                        # Override default URLs if provided in config
                        self.XRAY_BASE_URL = self.xray_cfg.get(
                            "XRAY_API_BASE_URL", self.XRAY_BASE_URL
                        )
                        self.XRAY_AUTH_URL = f"{self.XRAY_BASE_URL}/api/v2/authenticate"
                        self.XRAY_IMPORT_URL = (
                            f"{self.XRAY_BASE_URL}/api/v2/import/execution"
                        )
                    break

    def is_enabled(self) -> bool:
        reporting = self.config.get("reporting", [])
        for entry in reporting:
            if entry.get("name") == "XrayPlugin":
                return entry.get("enabled", False)
        return False

    def on_session_start(self, context: dict):
        self.token = self._authenticate()
        # Initialize Xray reporter for evidence collection
        reporter = XrayReporter()
        self._reporter = reporter

    def on_session_finish(self, context: dict):
        summary = context["summary"]

        # Optionally auto-create a Test Execution before importing results
        auto_create = (
            bool(getattr(self.xray_cfg, "auto_create_test_execution", False))
            if hasattr(self.xray_cfg, "auto_create_test_execution")
            else bool(self.xray_cfg.get("auto_create_test_execution", False))
        )
        if auto_create and not self.xray_cfg.get("test_execution_key"):
            created_key = self._create_test_execution(summary)
            if created_key:
                # persist into config for this run
                self.xray_cfg["test_execution_key"] = created_key

        # Reload all evidence files from disk (for xdist workers)
        if hasattr(self, "_reporter") and self._reporter:
            self.logger.debug("Reloading evidence files from disk...")
            self._reporter.reload_evidences()

        execution_payload = self._build_execution(summary)
        if execution_payload is None:
            self.logger.error(
                "Skipping Xray import: execution payload could not be built."
            )
            return
        self._import_execution(execution_payload)

        # Clean up evidence files after session finishes
        try:
            XrayReporter.cleanup_evidence_dir()
        except Exception as e:
            self.logger.debug(f"Failed to cleanup evidence directory: {e}")

    def _create_test_execution(self, summary: dict) -> str | None:
        """Create a Test Execution via Xray import endpoint by sending an empty tests list.
        Returns the created test execution key when available, otherwise None.
        """
        result: str | None = None

        info = {
            "project": self.xray_cfg.get("project_key"),
            "summary": f"Automation Execution – {summary.get('app_name', '')}",
        }
        payload = {"info": info, "tests": []}
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
        }

        try:
            self._validate_url(self.XRAY_IMPORT_URL)
            resp = requests.post(
                self.XRAY_IMPORT_URL,
                headers=headers,
                data=json.dumps(payload),
                timeout=self.REQUEST_TIMEOUT,
            )
            resp.raise_for_status()

            try:
                jr = resp.json()
            except ValueError:
                jr = None

            if isinstance(jr, dict):
                if isinstance(jr.get("testExecIssue"), dict):
                    result = jr["testExecIssue"].get("key")
                elif "testExecutionKey" in jr:
                    result = jr.get("testExecutionKey")
                elif "key" in jr:
                    result = jr.get("key")
                elif isinstance(jr.get("execution"), dict):
                    result = jr["execution"].get("key")

        except Exception:
            result = None

        return result

    # -------------------------------
    # XRAY AUTH
    # -------------------------------
    def _authenticate(self) -> Optional[str]:
        if self.XRAY_BASE_URL is None:
            logger.error("XRAY_BASE_URL is not configured for XrayPlugin.")
            return None
        xray_client_id, xray_client_secret = self._get_templated_config_values(
            self.xray_cfg
        )

        self._validate_url(self.XRAY_AUTH_URL)
        response = requests.post(
            self.XRAY_AUTH_URL,
            json={
                "client_id": xray_client_id,
                "client_secret": xray_client_secret,
            },
            timeout=self.REQUEST_TIMEOUT,
        )
        response.raise_for_status()
        return response.text.replace('"', "")

    def _get_templated_config_values(self, config_dict: dict):
        """
        Retrieves configuration values that may be templated with environment variable references.
        For example, if the config value is "${XRAY_CLIENT_ID}", it will look up the environment
        variable "XRAY_CLIENT_ID" and return its value. If the config value is not templated, it
        returns the value as is.
        """
        client_id_key = "XRAY_CLIENT_ID"
        client_secret_key = "XRAY_CLIENT_SECRET"

        xray_client_id = config_dict.get(client_id_key)
        xray_client_secret = config_dict.get(client_secret_key)

        if (
            isinstance(xray_client_id, str)
            and xray_client_id.startswith("${")
            and xray_client_id.endswith("}")
        ):
            env_var_name = xray_client_id[2:-1]
            xray_client_id = os.getenv(env_var_name)
            if not xray_client_id:
                self.logger.warning(
                    f"Environment variable '{env_var_name}' not found for XRAY_CLIENT_ID."
                )

        if (
            isinstance(xray_client_secret, str)
            and xray_client_secret.startswith("${")
            and xray_client_secret.endswith("}")
        ):
            env_var_name = xray_client_secret[2:-1]
            xray_client_secret = os.getenv(env_var_name)
            if not xray_client_secret:
                self.logger.warning(
                    f"Environment variable '{env_var_name}' not found for XRAY_CLIENT_SECRET."
                )

        return xray_client_id, xray_client_secret

    # -------------------------------
    # BUILD EXECUTION PAYLOAD
    # -------------------------------
    def _build_execution(self, summary: dict) -> Optional[dict]:
        if self.XRAY_BASE_URL is None:
            logger.error("XRAY_BASE_URL is not configured for XrayPlugin.")
            return None

        # Get all loaded evidence
        all_evidence = {}
        if hasattr(self, "_reporter") and self._reporter:
            all_evidence = self._reporter.get_all_evidence()
            self.logger.debug(f"Available evidence keys: {list(all_evidence.keys())}")

        tests = []
        for test in summary["tests"]:
            test_result = {
                "testKey": test["key"],
                "status": self._map_status(test["status"]),
                "comment": test.get("error_message", ""),
            }

            # Include evidence if available from reporter
            # Evidence is captured by XrayReporter during test execution
            evidence_list = []

            # Add traceback as evidence if present in comment field
            # Per Xray Cloud API, the data field must be base64-encoded regardless of content type
            error_trace = (
                test.get("error", "") if test.get("status") == "failed" else ""
            )
            if error_trace:
                # Encode string to bytes, then base64-encode
                tb_bytes = error_trace.encode("utf-8")
                tb_b64 = base64.b64encode(tb_bytes).decode("utf-8")
                evidence_list.append(
                    {
                        "filename": f"{test['key']}_traceback.txt",
                        "contentType": "text/plain",
                        "data": tb_b64,  # ✅ Base64-encoded per Xray API contract
                    }
                )

            # Add captured screenshots from reporter
            # Try multiple possible test name formats
            test_key = test.get("key", "")
            test_name = test.get("test_name", "")

            # Look for evidence using various keys
            # Filter out None/empty values to prevent AttributeError on .replace()
            possible_keys = [
                k
                for k in [
                    test_name if test_name else None,
                    (
                        test_name.replace("::", "_").replace("/", "_")
                        if test_name
                        else None
                    ),
                    test_key if test_key else None,
                    test_key.lower() if test_key else None,
                ]
                if k
            ]

            for key in possible_keys:
                if key and key in all_evidence:
                    captured_evidence = all_evidence[key]
                    if captured_evidence:
                        evidence_list.extend(captured_evidence)
                        self.logger.debug(
                            f"Found evidence for {test_key} using key: {key}"
                        )
                        break

            # Include evidence array in test result if any evidence exists
            if evidence_list:
                test_result["evidence"] = evidence_list

            tests.append(test_result)

        payload = {
            "info": {
                "project": self.xray_cfg.get("XRAY_PROJECT_KEY", ""),
                "summary": f"Automation Execution – {summary['app_name']}",
            },
            "tests": tests,
        }

        test_plan_key = self.xray_cfg.get("XRAY_TEST_PLAN_KEY", "")
        if test_plan_key:
            payload["info"]["testPlanKey"] = test_plan_key

        test_execution_key = self.xray_cfg.get("test_execution_key", "")
        if test_execution_key:
            payload["testExecutionKey"] = test_execution_key

        return payload

    def _map_status(self, pytest_status: str) -> str:
        return {"passed": "PASSED", "failed": "FAILED", "skipped": "TODO"}.get(
            pytest_status, "FAILED"
        )

    def _validate_and_filter_test_keys(
        self, tests_summary: list[dict]
    ) -> tuple[list[dict], int, list[str | None]]:
        """
        Analyzes a list of test summaries for valid Jira ID formats in their 'key' fields.
        A 'key' is considered valid if it matches the pattern <PROJECT_KEY>-<TICKET_ID>
        (e.g., "PROJ-123"), where PROJECT_KEY is alphanumeric and TICKET_ID is numeric.

        Args:
            tests_summary: A list of dictionaries, where each dictionary represents a test
                           and must contain a "key" field.

        Returns:
            A tuple containing:
            - A new list of test dictionaries that only include tests with valid Jira IDs.
            - The count of tests that were filtered out due to invalid Jira IDs.

        Raises:
            ValueError: If all test keys in the input `tests_summary` are invalid.
        """
        valid_tests_data = []
        failed_count = 0
        failed_test_keys = []

        for test in tests_summary:
            test_key = test.get("testKey")
            if test_key and self.JIRA_ID_PATTERN.match(test_key):
                valid_tests_data.append(test)
            else:
                failed_count += 1
                failed_test_keys.append(test_key)

        if not valid_tests_data:
            raise XrayTestKeyValidationError(
                f"All test keys in the provided summary failed validation.\nTotal failures: {failed_count}.\nKeys:\n{"\n".join(failed_test_keys)}."
            )

        return valid_tests_data, failed_count, failed_test_keys

    # -------------------------------
    # UPLOAD EXECUTION
    # -------------------------------
    def _sanitize_payload_for_logging(self, payload: dict) -> dict:
        """
        Create a sanitized copy of the payload for debug logging.
        Truncates base64-encoded evidence data to prevent log bloat.

        Args:
            payload: The full execution payload with embedded evidence

        Returns:
            dict: A copy of the payload with evidence data truncated for readability
        """
        loggable = copy.deepcopy(payload)

        # Truncate evidence data to prevent megabyte-sized logs
        for test in loggable.get("tests", []):
            for evidence in test.get("evidence", []):
                if "data" in evidence:
                    data_str = evidence.get("data", "")
                    data_len = len(data_str)
                    # Show first 100 chars + total length for context
                    evidence["data"] = (
                        f"<base64-data: {data_len} chars>"
                        if data_len > 100
                        else data_str
                    )

        return loggable

    def _import_execution(self, payload: dict):
        """
        Import test execution results via Xray Cloud API.
        Evidence is embedded directly in the payload (not separate API calls).
        """
        if self.XRAY_BASE_URL is None:
            logger.error("XRAY_BASE_URL is not configured for XrayPlugin.")
            return

        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
        }
        response = None
        try:
            # Validate and filter test keys before building the execution payload
            filtered_tests_summary, failed_test_keys_count, failed_test_keys = (
                self._validate_and_filter_test_keys(payload.get("tests", []))
            )
            payload["tests"] = filtered_tests_summary

            # Log a sanitized version to avoid log bloat from base64 data
            loggable_payload = self._sanitize_payload_for_logging(payload)
            self.logger.debug(
                f"Xray Import Payload: {json.dumps(loggable_payload, indent=2)}"
            )
            if failed_test_keys_count > 0:
                logger.debug(
                    f"Filtered out {failed_test_keys_count} tests with invalid Jira IDs: {failed_test_keys}"
                )
            self.logger.info(
                "Importing test execution results to Xray (with embedded evidence)..."
            )
            response = requests.post(
                self.XRAY_IMPORT_URL,
                headers=headers,
                data=json.dumps(payload),
                timeout=self.REQUEST_TIMEOUT,
            )
            response.raise_for_status()

        except XrayTestKeyValidationError as e:
            self.logger.debug(f"Test key validation error.")
            self.logger.debug(f"Reason: {str(e)}")
            return
        except requests.Timeout as e:
            self.logger.error(f"Timeout error during import to Xray.")
            self.logger.debug(f"Reason: {str(e)}")
            return
        except Exception as e:
            self.logger.error(f"Failed to import test execution to Xray.")
            self.logger.debug(f"Exception details: {str(e)}")
            reason = ""
            try:
                jr = response.json()
                reason = jr.get("error", str(jr))
            except Exception:
                reason = response.text
            self.logger.info(f"API error response: {reason}")
        else:
            self.logger.info("Test execution results successfully imported to Xray.")
            resp_json = {}
            try:
                resp_json = response.json()
            except Exception as e:
                self.logger.debug(
                    f"Failed to parse response JSON for successful Xray import: {e}"
                )
            else:
                jira_key = resp_json.get("key")
                if jira_key:
                    self.logger.info(f"Xray Test Execution Jira Key: {jira_key}")

    def _validate_url(self, url: str):
        """
        Validate the URL to prevent SSRF.
        Enforces HTTPS and optionally checks against allowlists if configured.
        """
        if not url:
            raise ValueError("URL cannot be empty")

        if not url.startswith("https://"):
            raise ValueError(f"Insecure URL scheme: {url}. Only 'https://' is allowed.")

        # Optional: Add domain validation if enterprise policy requires it
        allowed_domains = ["xray.cloud.getxray.app", "*.getxray.app", "*.xray.cloud"]
        if allowed_domains and not any(d in url for d in allowed_domains):
            raise ValueError(f"URL {url} is not in the allowed domains list.")

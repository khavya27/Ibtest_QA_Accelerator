# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

import glob
import inspect
import os
import shutil
import subprocess
import sys
from enum import Enum
from pathlib import Path
from typing import List, Optional

import requests as req
import typer
from dotenv import load_dotenv

from framework.core.cli import runner as cli_runner
from framework.core.cli.constants import TYPER_CONTEXT_SETTINGS
from framework.core.cli.enums import DebugLevelTypes, SplitLevelTypes
from framework.core.utils import get_logger, parse_bool
from framework.core.utils.generate_pytest_report import main as report_main
from framework.core.utils.logger import mask_secrets
from framework.core.utils.prepare_email_body import render_email_template
from framework.scaffold_suite.scaffold import create_scaffold

logger = get_logger()

app = typer.Typer(
    pretty_exceptions_enable=False, context_settings=TYPER_CONTEXT_SETTINGS
)


@app.callback()
def callback():
    """QA Runner with dynamic plugin loading for multiple apps."""
    pass  # Main entry point for the Typer app. Initialized when no command is given, to show help.


def get_param_list_for_log(run_command_frame) -> str:
    args = inspect.getargvalues(run_command_frame)
    params_list = [
        f"{k}={args.locals[k].value if isinstance(args.locals[k], Enum) else args.locals[k]}"
        for k in args.args
    ]
    return ",".join(params_list)


@app.command("run")
def run_command(
    app_name: str = typer.Option(
        ...,
        "--app",
        "-a",
        help="App name (e.g., saucedemo or saucedemo-ext). If not provided, runs all apps in `apps` directory under current directory.",
    ),
    config_file: str = typer.Option(
        "config.yaml",
        "--config",
        "-c",
        help="Config file name to use for the app(s).",
    ),
    workers_count: str | None = typer.Option(
        None,
        "--workers-count",
        "-w",
        help="Number of workers to use for parallel processing.",
    ),
    split_level: SplitLevelTypes = typer.Option(
        SplitLevelTypes.TEST_FILE.value,
        "--split-level",
        "-sl",
        help="Way to split files for parallel processing.",
        case_sensitive=True,
    ),
    reruns: int = typer.Option(
        3,
        "--reruns",
        "-rr",
        help="Number of re-run attempts.",
    ),
    reruns_delay: int = typer.Option(
        7,
        "--reruns-delay",
        "-rrd",
        help="Re-run delay in seconds.",
    ),
    debug_level: DebugLevelTypes = typer.Option(
        None, "--debug-level", "-dl", help="Set the debug log level."
    ),
    pytest_extra_args: List[str] = typer.Argument(
        None, help="Additional arguments to pass directly to pytest."
    ),
    generate_allure_report: bool = typer.Option(
        False,
        "--generate-allure-report",
        "-gar",
        help="Generate Allure report after test execution.",
    ),
    single_file_allure_report: bool = typer.Option(
        False,
        "--single-file-allure-report",
        "-sfar",
        help="Generate Allure report as a single HTML file. Requires --generate-allure-report/-gar to be set.",
    ),
    enable_pdb: bool = typer.Option(
        False,
        "--enable-pdb",
        "-pdb",
        help="Enable pdb debugging (disables parallel execution).",
    ),
):
    """Run QA tests for selected app(s) with dynamic plugin loading."""
    if debug_level:
        logger.set_log_level(debug_level.value)

    logger.debug("Loading environment variables from .env file")
    load_dotenv()

    # This value should be set to 'false' in development environments to
    # enable features like pdb debugging.
    IS_WHEEL_BUILD = parse_bool(os.getenv("IS_WHEEL_BUILD", "true"))

    if IS_WHEEL_BUILD:
        # Add the current working directory to sys.path for module resolution
        sys.path.append(os.getcwd())
        if enable_pdb:
            logger.critical(
                "PDB debugging is strictly not available from installed package. Only meant for development environments."
            )
            sys.exit(1)

    repo_root = os.getcwd()
    apps_dir = os.path.join(repo_root, "apps")
    unknown = pytest_extra_args

    logger.info("Starting IB Test Runner...")
    # get function params from inspect.currentframe
    logger.debug(f"Params: {get_param_list_for_log(inspect.currentframe())}")

    exit_codes = []
    if app_name:
        exit_code, summary, report = cli_runner.run_app(
            app_name,
            apps_dir,
            reruns=reruns,
            reruns_delay=reruns_delay,
            config_file=config_file,
            extras=unknown,
            split_level=getattr(split_level, "value", split_level),
            workers_count=workers_count,
            generate_allure_report=generate_allure_report,
            single_file_allure_report=single_file_allure_report,
            enable_pdb=enable_pdb,
        )
        exit_codes.append(exit_code)
    else:
        # Run all apps in apps/ folder (skip __init__.py, __pycache__)
        app_names = [
            d.name
            for d in Path(apps_dir).iterdir()
            if d.is_dir() and not d.name.startswith("__")
        ]
        exit_codes = []
        for app_name in app_names:
            exit_code, summary, report = cli_runner.run_app(
                app_name,
                apps_dir,
                reruns=reruns,
                reruns_delay=reruns_delay,
                config_file=config_file,
                extras=unknown,
                split_level=getattr(split_level, "value", split_level),
                workers_count=workers_count,
                generate_allure_report=generate_allure_report,
                single_file_allure_report=single_file_allure_report,
                enable_pdb=enable_pdb,
            )
            exit_codes.append(exit_code)

    logger.info("Completed all tasks.")
    max_exit_code = max(exit_codes)
    # Exit with nonzero if any failed
    if max_exit_code:
        logger.error("Some test-cases have failed.")
        sys.exit(max(exit_codes))


@app.command("setup")
def setup(
    app_name: str = typer.Option(
        ...,
        "--app",
        "-a",
        help="App name (e.g., saucedemo or slack).",
    ),
    scaffold: Optional[str] = typer.Option(
        None,
        "--scaffold",
        "-sc",
        help="Use 'true' to copy from existing app structure, omit or false for minimal template.",
    ),
):
    """Create a setup with one or more test suites."""

    def _validate_folder_name(name: str, field_name: str) -> None:
        """Validate that folder name contains only alphabets, numbers, and underscores."""
        if not name:
            typer.echo(f"Error: {field_name} cannot be empty.", err=True)
            raise typer.Exit(1)

        # Check if name contains only alphanumeric characters and underscores
        import re

        if not re.match(r"^[a-zA-Z0-9_]+$", name):
            typer.echo(
                f"Error: {field_name} '{name}' contains invalid characters.\n"
                f"Only alphabets (a-z, A-Z), numbers (0-9), and underscores (_) are allowed.",
                err=True,
            )
            raise typer.Exit(1)

        # Check for names that are reserved on Windows
        reserved_names = [
            "CON",
            "PRN",
            "AUX",
            "NUL",
            "COM1",
            "COM2",
            "COM3",
            "COM4",
            "COM5",
            "COM6",
            "COM7",
            "COM8",
            "COM9",
            "LPT1",
            "LPT2",
            "LPT3",
            "LPT4",
            "LPT5",
            "LPT6",
            "LPT7",
            "LPT8",
            "LPT9",
        ]
        if (
            name.upper() in reserved_names
            or name.upper().split(".")[0] in reserved_names
        ):
            typer.echo(
                f"Error: {field_name} '{name}' is a reserved name on Windows.", err=True
            )
            raise typer.Exit(1)

    # Validate app_name
    if app_name:
        _validate_folder_name(app_name, "App name")

    use_scaffold = parse_bool(scaffold)
    create_scaffold(app_name, use_scaffold_template=use_scaffold)

    if use_scaffold:
        print(f"Successfully set up app '{app_name}' using scaffold template")
    else:
        print(f"Successfully set up app '{app_name}' using minimal template")


@app.command("setup-pipeline")
def setup_pipeline():
    """
    Set up pipeline-related files (.github, requirements.txt, etc.) in the root directory.
    """
    logger.info("Starting pipeline setup...")
    from framework.scaffold_suite.scaffold import setup_pipeline_files
    setup_pipeline_files(Path.cwd())
    print("Successfully set up pipeline files in the root directory.")


@app.command("generate-report")
def generate_report(
    report_title: str = typer.Option(
        "Test Execution Summary",
        "--report-title",
        help="Title for the executive PDF report",
    ),
    detailed: bool = typer.Option(
        False,
        "--detailed",
        help="Include detailed test statistics",
        is_flag=True,
    ),
    results_file: str = typer.Argument(
        None,
        help="Path to pytest results JSON file",
    ),
    output: str = typer.Option(
        None,
        "--output",
        "-o",
        help="Output PDF file path",
    ),
):
    """
    Generate executive PDF report from pytest results.
    """
    logger.info("Generating executive report...")

    # Simulate CLI invocation expected by generate_pytest_report.main
    sys.argv = ["generate_pytest_report"]

    if results_file:
        sys.argv.append(results_file)

    if output:
        sys.argv.extend(["--output", output])

    sys.argv.extend(["--report-title", report_title])

    if detailed:
        sys.argv.append("--detailed")

    report_main()


@app.command("prepare-email")
def prepare_email(
    template_path: Path = typer.Option(
        ...,
        "--template-path",
        "-t",
        help="Path to email HTML template file",
        exists=True,
        file_okay=True,
        dir_okay=False,
    ),
):
    """
    Generate email body HTML from a template.
    Output is written in the same directory as the template.
    """
    logger.info("Preparing email body...")
    logger.debug(f"Template path: {template_path}")
    output_path = render_email_template(template_path)
    logger.info(f"Email body generated at: {output_path}")
    typer.echo(str(output_path))


@app.command("generate-api-test")
def generate_api_test(
    folder_name: str = typer.Argument(
        "generated_tests",
        help="Name of the folder to create under 'apps/' for generated tests.",
    ),
    schema_url: Optional[str] = typer.Option(
        None,
        "--schemaurl",
        help="URL pointing to the Swagger/OpenAPI schema.",
    ),
    schema_file: Optional[str] = typer.Option(
        None,
        "--schema",
        help="Path to a local Swagger/OpenAPI schema file.",
    ),
):
    """
    Run the API test generator.

    You must provide the API schema via exactly one of:
      --schemaurl   URL to a Swagger/OpenAPI schema
      --schema      Path to a local schema file
    """

    # --- Validate: exactly one of --schemaurl / --schema must be provided ---
    if schema_url and schema_file:
        logger.error("Provide either --schemaurl or --schema, not both.")
        raise typer.Exit(1)

    if not schema_url and not schema_file:
        logger.error(
            "Schema source is required.\n"
            "  Use --schemaurl <URL>   to download from a URL\n"
            "  Use --schema <path>     to use a local schema file"
        )
        raise typer.Exit(1)

    logger.info("Starting API Test Generator...")
    repo_root = os.getcwd()

    # Validation: output folder must be under apps/
    apps_dir = os.path.join(repo_root, "apps")
    target_output_dir = os.path.join(apps_dir, folder_name)

    # The api-test folder is in framework/api-test
    api_test_dir = os.path.join(repo_root, "framework", "api-test")
    script_path = os.path.join(api_test_dir, "run_test_generator.py")

    if not os.path.exists(script_path):
        logger.error(f"Test generator script not found at: {script_path}")
        sys.exit(1)

    # --- Download / copy schema into the api-test workspace ---
    if schema_url:
        try:
            resp = req.get(schema_url, timeout=15)
            resp.raise_for_status()
            # Determine filename from content type
            content_type = resp.headers.get("Content-Type", "")
            ext = ".json" if "json" in content_type else ".yaml"
            local_schema = os.path.join(api_test_dir, f"downloaded_schema{ext}")
            with open(local_schema, "w", encoding="utf-8") as f:
                f.write(resp.text)
            logger.info(f"Downloaded schema from: {schema_url}")
        except Exception as e:
            logger.error(f"Unable to download schema from provided URL: {e}")
            raise typer.Exit(1)
    else:
        if not os.path.isfile(schema_file):
            logger.error(f"Provided schema file does not exist: {schema_file}")
            raise typer.Exit(1)
        local_schema = os.path.join(api_test_dir, os.path.basename(schema_file))
        # Skip copy if src and dest resolve to the same path
        if os.path.abspath(schema_file) != os.path.abspath(local_schema):
            shutil.copy2(schema_file, local_schema)
            logger.info(f"Copied schema from: {schema_file}")
        else:
            logger.info("Schema file is already in workspace — skipping copy.")

    try:
        subprocess.check_call(
            [
                sys.executable,
                script_path,
                "--output",
                target_output_dir,
                "--schema-file",
                local_schema,
            ],
            cwd=api_test_dir,
        )
        logger.info(
            f"API Test Generator completed successfully. Output in: apps/{folder_name}"
        )
    except subprocess.CalledProcessError as e:
        logger.error(f"API Test Generator failed with exit code {e.returncode}")
        sys.exit(e.returncode)


@app.command("run-tests")
def run_tests(
    folder_name: str = typer.Argument(
        ...,
        help="Name of the folder inside 'apps/' containing test cases.",
    ),
):
    """
    Run pytest for a specific application folder inside apps/.

    Example:
      python ibtest.py run-tests my-tests
    """
    repo_root = os.getcwd()
    apps_dir = os.path.join(repo_root, "apps")
    target_dir = os.path.join(apps_dir, folder_name)

    # --- Validation ---
    if not os.path.isdir(target_dir):
        logger.error(
            f"Specified folder does not exist inside apps directory: apps/{folder_name}"
        )
        raise typer.Exit(1)

    # Check for pytest-compatible test files
    test_files = glob.glob(os.path.join(target_dir, "test_*.py")) + glob.glob(
        os.path.join(target_dir, "*_test.py")
    )
    if not test_files:
        logger.error(f"No pytest test cases found in: apps/{folder_name}")
        raise typer.Exit(1)

    logger.info(
        f"Running pytest for apps/{folder_name} ({len(test_files)} test file(s) found)"
    )

    try:
        result = subprocess.run(
            [sys.executable, "-m", "pytest", "-s", target_dir], cwd=repo_root
        )
        sys.exit(result.returncode)
    except Exception as e:
        logger.error(f"Failed to run pytest: {e}")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()

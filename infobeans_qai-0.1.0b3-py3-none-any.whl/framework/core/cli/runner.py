# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

import json
import os
import tempfile
from typing import List, Optional, Tuple

import pytest

from framework.core.cli.constants import REPORTS_DIR_NAME
from framework.core.utils import get_logger, parse_yaml_content
from framework.plugins.manager import PluginManager

from .helpers import (
    compute_test_summary,
    generate_allure_report_files,
    is_allure_enabled,
    load_plugins,
    merge_json_reports,
    parse_raw_json_report_dict,
    save_json_report,
)

logger = get_logger()


def load_app_config(app_name, yaml_file="config.yaml", yaml_path=None):
    if not yaml_path:
        yaml_path = os.path.join("apps", app_name)
    if os.path.isabs(yaml_path) and not os.path.isabs(yaml_file):
        config_path = os.path.join(yaml_path, yaml_file)
    elif os.path.isabs(yaml_file):
        config_path = yaml_file
    else:
        config_path = os.path.join(os.getcwd(), yaml_path, yaml_file)
    logger.debug(f"Loading config for app {app_name} from: {config_path}")
    with open(config_path, "r", encoding="utf-8") as f:
        return parse_yaml_content(f)


def create_json_report_file(app_path: str, suffix: Optional[str] = None) -> str:
    json_report = os.path.join(
        app_path,
        REPORTS_DIR_NAME,
        f"pytest_report{('-' + suffix) if suffix else ''}.json",
    )
    try:
        if os.path.exists(json_report):
            os.remove(json_report)
    except Exception:
        pass
    return json_report


def get_allure_results_dir(context):
    reporting_cfg = context["config"].get("reporting", [])
    allure_cfg = None
    for entry in reporting_cfg:
        if entry.get("name") == "AllurePlugin":
            allure_cfg = entry.get("config", False)
            break
    if allure_cfg:
        app_path = context.get("app_path")
        return os.path.join(app_path, REPORTS_DIR_NAME, allure_cfg["allure_dir"])
    return None


def setup_xray_evidence_dir(app_path: str) -> str:
    """
    Create a unique session-scoped evidence directory for Xray evidence collection.

    This directory is used by all pytest-xdist workers to store screenshot evidence
    during test execution. The directory path is also set as an environment variable
    so that worker processes inherit it automatically.

    Args:
        app_path: Path to the application being tested

    Returns:
        str: Path to the created evidence directory
    """
    # Create a unique temporary directory with session prefix
    evidence_dir = tempfile.mkdtemp(
        prefix=f"xray_evidence_{os.path.basename(app_path)}_"
    )

    # Set environment variable for xdist workers to inherit
    os.environ["IBTEST_XRAY_EVIDENCE_DIR"] = evidence_dir

    logger.debug(f"Created Xray evidence directory: {evidence_dir}")
    return evidence_dir


def get_pytest_params(
    app_path,
    context,
    json_report_file,
    reruns,
    reruns_delay,
    extras=None,
    workers_count=None,
    split_level=None,
    dist_scope=None,
    testfiles: Optional[List[str]] = None,
    enable_pdb: bool = False,
):
    # set app path
    pytest_params = [app_path]

    # pytest xdist params
    if not workers_count and not enable_pdb:
        workers_count = os.getenv("PYTEST_XDIST_WORKER_COUNT", "auto")

    if enable_pdb:
        pytest_params += ["--pdb"]
        workers_count = "0"  # disable xdist when pdb enabled

    pytest_params += ["-n", str(workers_count)]

    if testfiles:
        pytest_params += testfiles
    else:
        pytest_params += [app_path]

    # set re-runs for failures
    pytest_params += ["--reruns", str(reruns), "--reruns-delay", str(reruns_delay)]
    if split_level:
        xdist_mode = "loadfile"  # test_file level
        if split_level == "module":
            xdist_mode = "loadscope"
        pytest_params += [f"--dist={xdist_mode}"]
    elif dist_scope:
        pytest_params += [f"--dist={dist_scope}"]

    # skip extra information in output
    pytest_params += ["--no-header", "--no-summary"]

    # extra params
    if extras:
        pytest_params += extras

    # Browser settings from config.yaml — translate to pytest-playwright flags.
    # config.yaml supports: browser (chromium/firefox/webkit), headless (true/false)
    browser = context.get("config", {}).get("browser", "chromium")
    headless = context.get("config", {}).get("headless", True)
    pytest_params += ["--browser", str(browser)]
    if not headless:
        pytest_params += ["--headed"]

    # allure reports
    allure_path = get_allure_results_dir(context)

    if allure_path:
        pytest_params += ["--alluredir", allure_path]

    # connecting Jira Xray hook
    pytest_params += ["-p", "framework.hooks.pytest_xray_hook"]

    # connecting allure attachment hook
    pytest_params += ["-p", "framework.hooks.pytest_allure_attachment_hook"]

    # json report (for parsing results)
    pytest_params += ["--json-report", "--json-report-file", json_report_file]

    # junit xml report
    junit_report = os.path.join(app_path, REPORTS_DIR_NAME, "test-results.xml")
    pytest_params += ["--junitxml", junit_report]

    # html report
    html_report = os.path.join(app_path, REPORTS_DIR_NAME, "report.html")
    pytest_params += ["--html", html_report, "--self-contained-html"]
    logger.debug(f"Generated pytest params: {pytest_params}")
    return pytest_params


def get_test_summary_from_json_report(app_name, json_report_file):
    # Collect summary info for reporting from pytest json report
    all_tests = []
    total = passed = failed = skipped = error = 0
    wall_clock = 0
    total_effort = 0

    try:
        if os.path.exists(json_report_file):
            with open(json_report_file, "r", encoding="utf-8") as jf:
                jr = json.load(jf)
            
            for raw_tests_dict in jr.get("tests", []):
                all_tests.append(parse_raw_json_report_dict(raw_tests_dict))
            
            # deduplicate by nodeid, keeping the last seen result (crucial for reruns)
            distinct_tests = {}
            for t in all_tests:
                distinct_tests[t["nodeid"]] = t
            
            dedup_tests = list(distinct_tests.values())
            wall_clock = jr.get("duration", 0)
            
            # compute summary using shared helper
            summary_stats = compute_test_summary(dedup_tests, wall_clock)
            
            total = summary_stats["total"]
            passed = summary_stats["passed"]
            failed = summary_stats["failed"]
            skipped = summary_stats["skipped"]
            total_effort = summary_stats["total_effort"]
            all_tests = dedup_tests

            if "created" not in jr:
                import time
                jr["created"] = str(time.time())
            
            # Save corrected report using shared helper
            save_json_report(json_report_file, all_tests, summary_stats, wall_clock, jr["created"])

    except Exception as e:
        # if anything goes wrong, fall back to placeholder counts
        logger.debug(f"Error updating JSON report summary: {e}")
        all_tests = []
        total = passed = failed = skipped = error = 0
        wall_clock = 0
        total_effort = 0

    summary = {
        "app_name": app_name,
        "total": total,
        "passed": passed,
        "failed": failed,
        "skipped": skipped,
        "duration": wall_clock,
        "total_effort": total_effort,
        "tests": all_tests,
    }
    return summary


def run_single_run(
    app_name: str,
    app_path: str,
    config: dict,
    extras: Optional[List[str]],
    split_level: Optional[str],
    workers_count: Optional[str],
    reruns: int,
    reruns_delay: int,
    testfiles: Optional[List[str]] = None,
    suffix: Optional[str] = None,
    plugin_manager: Optional[PluginManager] = None,
    context: Optional[dict] = None,
    dist_scope: Optional[str] = None,
    enable_pdb: bool = False,
) -> Tuple[int, dict, str]:
    # If no plugin_manager passed, create an empty manager and manage its lifecycle here
    if context is None:
        context = {"app_name": app_name, "config": config, "app_path": app_path}
    if plugin_manager is None:
        # create plugins from config if available
        reporting = config.get("reporting", [])
        plugins = load_plugins(reporting, config)  # []
        plugin_manager = PluginManager(plugins)

    json_report = create_json_report_file(app_path, suffix=suffix)
    pytest_params = get_pytest_params(
        app_path,
        context,
        json_report_file=json_report,
        extras=extras,
        split_level=split_level,
        workers_count=workers_count,
        reruns=reruns,
        reruns_delay=reruns_delay,
        dist_scope=dist_scope,
        testfiles=testfiles,
        enable_pdb=enable_pdb,
    )
    logger.info(f"Running pytest for {app_name} (files: {testfiles or 'ALL'})")
    exit_code = pytest.main(pytest_params)

    summary = get_test_summary_from_json_report(app_name, json_report)

    return exit_code, summary, json_report


def run_app(
    app_name: str,
    apps_dir: str,
    reruns: int,
    reruns_delay: int,
    config_file: Optional[str] = None,
    extras: Optional[List[str]] = None,
    split_level: Optional[str] = None,
    workers_count: Optional[str] = None,
    generate_allure_report: Optional[bool] = False,
    single_file_allure_report: Optional[bool] = False,
    enable_pdb: Optional[bool] = False,
):
    app_path = os.path.join(apps_dir, app_name)
    config = load_app_config(app_name, yaml_file=config_file)
    exit_code, summary, json_report = 0, None, None

    cp = config.get("custom_parallel_run")
    # Prepare plugins and plugin manager for the whole app session
    reporting = config.get("reporting", [])
    plugins = load_plugins(reporting, config)  # []

    plugin_manager = PluginManager(plugins)

    # Setup Xray evidence directory before session starts
    # This ensures all xdist workers use the same directory
    evidence_dir = setup_xray_evidence_dir(app_path)

    context = {
        "app_name": app_name,
        "config": config,
        "app_path": app_path,
        "xray_evidence_dir": evidence_dir,  # Pass to plugins
    }
    try:
        plugin_manager.session_start(context)
    except Exception as e:
        logger.error(f"Exception during plugin session start: {str(e)}")

    # If custom run not enabled, run normal single invocation
    if not cp or not cp.get("enabled"):
        exit_code, summary, json_report = run_single_run(
            app_name,
            app_path,
            config,
            extras,
            split_level,
            workers_count,
            reruns,
            reruns_delay,
            plugin_manager=plugin_manager,
            context=context,
            enable_pdb=enable_pdb,
        )
    else:  # Custom parallel run
        batches = cp.get("batches", {})
        batch_jsons = []
        batch_summaries = []
        # max_exit = 0
        for batch_name, batch_cfg in batches.items():
            testfiles = batch_cfg.get("testfiles")
            workers = batch_cfg.get("workers") or workers_count
            dist_scope = batch_cfg.get("dist_scope")
            # run the batch. (sr_ = single run)
            sr_exit_code, sr_summary, sr_json_report = run_single_run(
                app_name,
                app_path,
                config,
                extras,
                split_level,
                workers,
                reruns,
                reruns_delay,
                testfiles=testfiles,
                suffix=str(batch_name),
                plugin_manager=plugin_manager,
                context=context,
                dist_scope=dist_scope,
                enable_pdb=enable_pdb,
            )
            batch_jsons.append(sr_json_report)
            batch_summaries.append(sr_summary)
            if sr_exit_code and sr_exit_code > exit_code:
                exit_code = sr_exit_code

        # Merge results
        json_report = os.path.join(app_path, REPORTS_DIR_NAME, "pytest_report.json")
        summary = merge_json_reports(app_name, batch_jsons, json_report)

    # finish plugins for the whole session
    try:
        context["summary"] = summary
        plugin_manager.session_finish(context)
    except Exception as e:
        logger.error(f"Exception during plugin session finish: {str(e)}")
        logger.debug(f"Context dict: {context}")

    if generate_allure_report and is_allure_enabled(config.get("reporting", [])):
        logger.info("Preparing to generate Allure report...")
        # run allure generate command after pytest run
        allure_path = get_allure_results_dir(context)
        logger.info("Generating Allure report...")
        generate_allure_report_files(allure_path, single_file=single_file_allure_report)
        logger.info("Completed generating Allure report...")

    # return combined exit and summary
    return exit_code, summary, json_report

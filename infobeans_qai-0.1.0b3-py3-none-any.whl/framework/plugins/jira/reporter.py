import base64
import json
import os
import shutil
import tempfile

from framework.core.utils import get_logger

logger = get_logger()

# Environment variable key for the session-scoped evidence directory
# Set by runner.py before pytest execution to ensure all workers use the same directory
_EVIDENCE_DIR_ENV_KEY = "IBTEST_XRAY_EVIDENCE_DIR"


class XrayReporter:
    """
    Reporter for capturing evidence during test execution.
    Similar to AllurePytestReporter, captures screenshots from page object on test failure.
    Evidence is stored to disk to support pytest-xdist parallel execution.
    """

    def __init__(self, evidence_dir: str = None):
        """
        Initialize XrayReporter with optional evidence directory.

        Args:
            evidence_dir: Path to evidence directory. If not provided, will attempt
                         to read from environment variable IBTEST_XRAY_EVIDENCE_DIR.
                         If neither is available, will create a default directory.
        """
        self.evidence_dir = evidence_dir or self._get_evidence_dir()
        self.evidence_store = {}  # In-memory cache for loaded evidence

    @staticmethod
    def _get_evidence_dir() -> str:
        """
        Get the evidence directory from environment variable.

        The directory should be set by runner.py before pytest execution.
        For xdist workers, this environment variable is automatically inherited.

        Returns:
            str: Path to the evidence directory
        """
        evidence_dir = os.environ.get(_EVIDENCE_DIR_ENV_KEY)
        if evidence_dir and os.path.isdir(evidence_dir):
            return evidence_dir

        # Fallback: create a temporary directory if env var is not set
        # This can happen if XrayReporter is instantiated outside of normal test flow
        fallback_dir = tempfile.mkdtemp(prefix="xray_evidence_")
        logger.debug(
            f"Evidence directory not set in environment, using fallback: {fallback_dir}"
        )
        return fallback_dir

    def handle_failure(self, item: object, page: object = None) -> None:
        """
        Handle test failure and capture evidence.

        Args:
            item: pytest test item
            page: page fixture for taking screenshots
        """
        test_name = item.name

        # Capture screenshot if page object is available
        if page is not None:
            try:
                screenshot_data = self._capture_screenshot(page)
                if screenshot_data:
                    # Save evidence to file
                    self._save_evidence(test_name, screenshot_data)
                    logger.debug(f"Screenshot captured and saved for {test_name}")
            except Exception as e:
                logger.debug(f"Failed to capture screenshot for {test_name}: {e}")

    def _capture_screenshot(self, page: object) -> None:
        """
        Capture screenshot from page object.
        Returns evidence dict with base64 encoded image data.
        """
        try:
            # Capture screenshot using page.screenshot()
            screenshot_bytes = page.screenshot()

            screenshot_b64 = base64.b64encode(screenshot_bytes).decode("utf-8")

            return {
                "filename": "screenshot.png",
                "contentType": "image/png",
                "data": screenshot_b64,  # Base64 encoded data for JSON payload
            }
        except Exception as e:
            logger.debug(f"Failed to capture screenshot: {e}")
            return None

    def _save_evidence(self, test_name: str, evidence_data: dict) -> None:
        """Save evidence to a file."""
        try:
            # Create a safe filename from test name
            safe_name = test_name.replace("::", "_").replace("/", "_")
            if safe_name.endswith("]"):
                safe_name = safe_name[: safe_name.rfind("[")]
            evidence_file = os.path.join(
                self.evidence_dir, f"{safe_name}_evidence.json"
            )

            # Write evidence to file
            with open(evidence_file, "w") as f:
                json.dump([evidence_data], f)

            logger.debug(f"Evidence saved to {evidence_file}")
        except Exception as e:
            logger.debug(f"Failed to save evidence to file: {e}")

    def get_evidence(self, test_name: str) -> list:
        """Retrieve captured evidence for a test from disk."""
        try:
            safe_name = test_name.replace("::", "_").replace("/", "_")
            evidence_file = os.path.join(
                self.evidence_dir, f"{safe_name}_evidence.json"
            )

            if os.path.exists(evidence_file):
                with open(evidence_file, "r") as f:
                    return json.load(f)
        except Exception as e:
            logger.debug(f"Failed to read evidence from file: {e}")
        return []

    def reload_evidences(self) -> None:
        """
        Reload all evidence files from disk into memory.
        Call this before building the execution payload to collect evidence
        from all xdist workers.

        Updates self.evidence_store with all evidence files found.
        """
        try:
            if not self.evidence_dir or not os.path.exists(self.evidence_dir):
                logger.debug("Evidence directory does not exist")
                return
            logger.debug(f"Reloading evidences from directory: {self.evidence_dir}")
            # Clear existing in-memory cache
            self.evidence_store.clear()

            # Scan all evidence files in the directory
            for filename in os.listdir(self.evidence_dir):
                if filename.endswith("_evidence.json"):
                    evidence_file = os.path.join(self.evidence_dir, filename)
                    try:
                        with open(evidence_file, "r") as f:
                            evidence_data = json.load(f)

                        # Extract test name from filename
                        # Filename format: {test_name}_evidence.json
                        test_name = filename.replace("_evidence.json", "")

                        # Store in memory for quick access
                        self.evidence_store[test_name] = evidence_data
                        logger.debug(
                            f"Loaded evidence for {test_name}: {len(evidence_data)} items"
                        )
                    except Exception as e:
                        logger.debug(f"Failed to load evidence file {filename}: {e}")

            logger.debug(
                f"Reloaded evidence from {len(self.evidence_store)} test files"
            )
        except Exception as e:
            logger.debug(f"Failed to reload evidences: {e}")

    def get_all_evidence(self) -> dict:
        """Get all loaded evidence from the in-memory cache."""
        return self.evidence_store.copy()

    @staticmethod
    def cleanup_evidence_dir() -> None:
        """Clean up the session evidence directory after tests complete."""
        evidence_dir = os.environ.get(_EVIDENCE_DIR_ENV_KEY)
        if evidence_dir and os.path.exists(evidence_dir):
            try:
                shutil.rmtree(evidence_dir)
                logger.debug(f"Cleaned up evidence directory: {evidence_dir}")
            except Exception as e:
                logger.debug(f"Failed to cleanup evidence directory: {e}")
            finally:
                # Clear the env var
                os.environ.pop(_EVIDENCE_DIR_ENV_KEY, None)

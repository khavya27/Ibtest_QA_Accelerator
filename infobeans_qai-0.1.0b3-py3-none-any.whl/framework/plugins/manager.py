# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.


class PluginManager:
    def __init__(self, plugins: list):
        self.plugins = [p for p in plugins if p.is_enabled()]

    def session_start(self, context: dict):
        for plugin in self.plugins:
            plugin.on_session_start(context)

    def session_finish(self, context: dict):
        for plugin in self.plugins:
            plugin.on_session_finish(context)

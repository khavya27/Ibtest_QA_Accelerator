# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.


import os

import allure

from framework.core.utils import get_logger
from framework.plugins.base import Plugin

from .reporter import AllurePytestReporter

logger = get_logger()


class AllurePlugin(Plugin):
    def __init__(self, config):
        self.config = config
        self.reporter = None

    def is_enabled(self) -> bool:
        reporting = self.config.get("reporting", [])
        for entry in reporting:
            if entry.get("name") == "AllurePlugin":
                return entry.get("enabled", False)
        return False

    def on_session_start(self, context: dict):
        """
        Initialize Allure environment and reporter.
        """
        app_path = os.path.join(os.getcwd(), "apps", context.get("app_path"))
        report_path = os.path.join(app_path, "reports")

        # Set screenshot directory under the same parent as allure results
        screenshot_dir = context.get(
            "screenshot_dir", os.path.join(report_path, "screenshots")
        )
        self.reporter = AllurePytestReporter(screenshot_dir=screenshot_dir)

        # Expose reporter for pytest hooks (same instance)
        context["allure_reporter"] = self.reporter

    def on_session_finish(self, context: dict):
        # Nothing to do here – pytest handles results
        """
        Final Allure enrichment after test execution.
        This runs once per session via PluginManager.
        """
        summary = context.get("summary", {})

        # Attach final execution metadata
        try:
            allure.attach(
                str(summary),
                name="Execution Summary",
                attachment_type=allure.attachment_type.JSON,
            )
        except Exception:
            # Allure must never fail the pipeline
            pass

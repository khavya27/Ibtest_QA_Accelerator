# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

import os
import time
from pathlib import Path

import allure
from allure_commons.types import AttachmentType

from framework.core.utils import get_logger

logger = get_logger()


class AllurePytestReporter:
    """Allure reporter for attaching screenshots, tracebacks, and step descriptions."""

    def __init__(self, screenshot_dir: str = ""):
        if screenshot_dir:
            os.environ["ALLURE_SCREENSHOT_DIR"] = screenshot_dir
            self.screenshot_dir = screenshot_dir
            self._create_screenshot_dir(screenshot_dir)

    def _create_screenshot_dir(self, screenshot_dir) -> str:
        Path(screenshot_dir).mkdir(parents=True, exist_ok=True)

    def attach_screenshot(self, screenshot_path: str = ""):
        """Attach screenshot to failed test."""
        try:
            # If a Playwright page was attached to the test item, prefer taking
            # an on-demand screenshot from that page so the image reflects the
            # actual browser state at failure.
            item = None
            try:
                # caller may set `item` attribute on this reporter via handle_failure
                item = getattr(self, "_last_failed_item", None)
            except Exception:
                item = None

            if item is not None and getattr(item, "_request", None) is not None:
                page = item._request.getfixturevalue("page")
                # ensure screenshot dir exists
                if not hasattr(self, "screenshot_dir"):
                    self.screenshot_dir = os.environ["ALLURE_SCREENSHOT_DIR"]
                    self._create_screenshot_dir(self.screenshot_dir)
                dest = os.path.join(
                    self.screenshot_dir, f"screenshot_{int(time.time())}.png"
                )

                try:
                    # Skip screenshot if the page hasn't navigated anywhere meaningful
                    if page.url == "about:blank":
                        logger.debug("Skipping screenshot: page is about:blank")
                        return

                    # Add a small delay to allow the UI to render and buffers to flush
                    # This helps avoid blank/white screenshots
                    time.sleep(1)

                    logger.info(f"Capturing failure screenshot for URL: {page.url}")
                    page.screenshot(path=dest, timeout=5000)

                    if dest and os.path.exists(dest):
                        with open(dest, "rb") as img:
                            allure.attach(
                                img.read(),
                                name="Failure Screenshot",
                                attachment_type=AttachmentType.PNG,
                            )
                        return
                except Exception as e:
                    # If taking screenshot from page failed, continue to fallback
                    logger.debug(f"Failed to take screenshot from page: {e}")
        except Exception as e:
            allure.step(f"Failed to attach screenshot: {str(e)}")
            logger.debug(f"Failed to attach screenshot: {e}")

    def attach_traceback(self, exc_info):
        """Attach traceback string to failed test."""
        if exc_info:
            # TODO: Fix this line
            tb_str = str(exc_info)
            allure.attach(tb_str, name="Traceback", attachment_type=AttachmentType.TEXT)

    def handle_failure(self, item, call):
        """Handle test failure by attaching screenshot and traceback."""
        if call.excinfo:
            # remember last failed item so attach_screenshot can access it
            try:
                self._last_failed_item = item
            except Exception as e:
                logger.debug(f"Failed to set last failed item on reporter: {e}")

            self.attach_traceback(call.excinfo)

            # Attach screenshot for UI tests (use Playwright page if available)
            self.attach_screenshot()

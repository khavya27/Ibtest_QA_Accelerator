# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

import os
from pathlib import Path

from framework.plugins.base import Plugin


class HtmlReportPlugin(Plugin):
    def __init__(self, config):
        self.config = config

    def is_enabled(self) -> bool:
        reporting = self.config.get("reporting", [])
        for entry in reporting:
            if entry.get("name") == "HtmlReportPlugin":
                return entry.get("enabled", False)
        return False

    def on_session_start(self, context: dict):
        pass

    def on_session_finish(self, context: dict):
        app_path = context.get("app_path")
        summary = context["summary"]
        output = Path(os.path.join(app_path, "reports", "html"))
        output.mkdir(parents=True, exist_ok=True)

        report_path = Path(os.path.join(output, "index.html"))
        report_path.write_text(self._render(summary), encoding="utf-8")

    def _render(self, summary: dict) -> str:
        return f"""
<!DOCTYPE html>
<html>
<head>
  <title>Automation Report – {summary['app_name']}</title>
  <style>
    body {{ font-family: Arial; padding: 20px; }}
    .pass {{ color: green; }}
    .fail {{ color: red; }}
  </style>
</head>
<body>
  <h1>Automation Execution Summary</h1>
  <p><b>Application:</b> {summary['app_name']}</p>
  <p><b>Total:</b> {summary['total']}</p>
  <p class="pass"><b>Passed:</b> {summary['passed']}</p>
  <p class="fail"><b>Failed:</b> {summary['failed']}</p>
</body>
</html>
"""

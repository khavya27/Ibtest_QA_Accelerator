# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

from playwright.async_api import async_playwright

from framework.core.utils import get_logger

logger = get_logger()


class BrowserFactory:
    def __init__(self, config):
        self.config = config
        self.playwright = None
        self.browser = None
        self.context = None

    async def __aenter__(self):
        self.playwright = async_playwright().start()
        browser_type = getattr(self.playwright, self.config.browser)
        self.browser = await browser_type.launch(headless=self.config.headless)
        self.context = await self.browser.new_context()
        # Enable Tracing for debugging
        self.context.tracing.start(screenshots=True, snapshots=True)
        return await self.context

    async def __aexit__(self, exc_type=None, exc_value=None, traceback=None):
        logger.debug("Closing browser and context.")
        if self.context:
            await self.context.close()
        if self.browser:
            await self.browser.close()
        if self.playwright:
            await self.playwright.stop()

        # log tracing info if any exception occurred
        if exc_type and exc_value:
            logger.debug(f"Exc type: {exc_type}, value: {exc_value}")
        if traceback:
            logger.debug(f"Traceback: {traceback}")

    async def astart(self):
        return await self.__enter__()

    async def astop(self):
        return await self.__exit__()

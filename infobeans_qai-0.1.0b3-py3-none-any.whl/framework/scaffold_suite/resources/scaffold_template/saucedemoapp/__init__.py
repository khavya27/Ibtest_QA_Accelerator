"""saucedemo application module."""

__all__: list[str] = []

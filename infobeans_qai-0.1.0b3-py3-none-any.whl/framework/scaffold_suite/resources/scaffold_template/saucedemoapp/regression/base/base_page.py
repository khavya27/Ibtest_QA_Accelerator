from typing import Optional

from playwright.sync_api import Locator, Page

from apps.saucedemoapp.regression.utils.logger import get_logger

# AutoHealer removed — AI-based auto-healing disabled

logger = get_logger()


class BasePage:
    def __init__(self, page: Page):
        self.page = page
        # AutoHealer removed — no AI healing
        logger.debug("AutoHealer feature disabled; using deterministic locator strategies only")

    def get_element(self, selector: str, description: str = "element") -> Locator:
        # First attempt: Try the normal way of searching the locator
        element = self.page.locator(selector)
        # Check if element exists and is visible
        if element.count() == 0:
            logger.warning(f"Element not found with locator: {selector} using normal locator")
            raise AssertionError(f"Element not found with locator: {selector} using normal locator")
        logger.info(f"Successfully found element using original locator: {selector}")
        return element

    def fill(
        self,
        selector: str,
        value: str,
        timeout: int = 5000,
        description: str = "input field",
        is_password: bool = False,
    ):
        try:
            password_val = f"{value[:2]}{'*' * len(value[2:-2])}{value[-2:]}" if is_password else value
            logger.debug(f"Entering text:'{password_val}' to element '{selector}'")
            normal_locator = True
            # Try with normal locator first
            try:
                element = self.get_element(selector, description)
            except Exception as e:
                logger.error(
                    f"Failed to locate element '{selector}' with normal locator: {str(e)}; trying fallback wait_for_selector"
                )
                element = None
                normal_locator = False
                # Try waiting for the original selector as a fallback
                try:
                    el_wait = self.page.wait_for_selector(selector, timeout=timeout)
                    if el_wait is not None:
                        element = el_wait
                        logger.info(f"Fallback selector matched element after wait: {selector}")
                except Exception:
                    logger.debug(f"Fallback wait_for_selector did not find element: {selector}")
            # If element is found, fill it

            if element:
                element.fill(value)
                logger.info(
                    f"Successfully filled element '{selector if normal_locator == True else suggestion}' using {'normal locator' if normal_locator else 'AutoHealer'}"
                )
                return True

            # Fallback to original method if healer fails
            el = self.page.wait_for_selector(selector, timeout=timeout)
            assert el is not None, f"Element '{selector}' not found for fill."
            el.fill(value)
            logger.info(f"Successfully filled element '{selector}' using fallback")
            return True
        except Exception as e:
            # Try to save DOM snapshot for debugging
            try:
                snapshot = self._save_dom_snapshot(description)
                logger.info(f"Saved DOM snapshot due to fill failure: {snapshot}")
            except Exception as s:
                logger.debug(f"Failed to save DOM snapshot on error: {s}")

            logger.error(
                f"Fill action failed for '{selector}': {str(e)} | page_url={getattr(self.page, 'url', 'unknown')} | page_title={getattr(self.page, 'title', lambda: 'unknown')() if hasattr(self.page, 'title') else 'unknown'}"
            )
            raise AssertionError(f"Fill action failed for '{selector}': {str(e)}") from e

    def click(self, selector: str, timeout: int = 5000, description: str = "clickable element"):
        try:
            logger.debug(f"Clicking element '{selector}'")

            # Try with normal locator first
            try:
                element = self.get_element(selector, description)
                normal_locator = True
            except Exception as e:
                logger.error(
                    f"Failed to locate element '{selector}' with normal locator: {str(e)}; trying fallback wait_for_selector"
                )
                element = None
                normal_locator = False
                try:
                    el_wait = self.page.wait_for_selector(selector, timeout=timeout)
                    if el_wait is not None:
                        element = el_wait
                        logger.info(f"Fallback selector matched element after wait: {selector}")
                except Exception:
                    logger.debug(f"Fallback wait_for_selector did not find element: {selector}")
            # If element is found, click it

            if element:
                element.click()
                logger.info(
                    f"Successfully clicked element '{selector if normal_locator == True else suggestion}' using {'normal locator' if normal_locator else 'AutoHealer'}"
                )
                return True
            else:
                # If AutoHealer returns None, it means all healing attempts failed
                logger.error(
                    f"AutoHealer could not locate element '{description}' with locator '{selector}' after all healing attempts"
                )
                raise AssertionError(
                    f"Element '{description}' not found with locator '{selector}' even after AI healing attempts"
                )

        except Exception as e:
            logger.error(f"Click action failed for '{selector}': {str(e)}")
            raise AssertionError(f"Click action failed for '{selector}': {str(e)}") from e

    def text_content(self, selector: str, description: str = "text element"):
        try:
            logger.debug(f"Getting text content from element '{selector}'")

            # Try with normal locator first
            try:
                element = self.get_element(selector, description)
                normal_locator = True
            except Exception as e:
                logger.error(
                    f"Failed to locate element '{selector}' with normal locator: {str(e)}; trying fallback wait_for_selector"
                )
                element = None
                normal_locator = False
                try:
                    el_wait = self.page.wait_for_selector(selector, timeout=2000)
                    if el_wait is not None:
                        element = el_wait
                        logger.info(f"Fallback selector matched element after wait: {selector}")
                except Exception:
                    logger.debug(f"Fallback wait_for_selector did not find element: {selector}")
            # If element is found, get text content
            if element:
                text = element.text_content()
                if text is not None:
                    logger.info(
                        f"Successfully retrieved text content from element '{selector if normal_locator == True else suggestion}' using {'normal locator' if normal_locator else 'AutoHealer'}"
                    )
                    return text

        except Exception as e:
            logger.error(f"text_content action failed for '{selector}': {str(e)}")
            raise AssertionError(f"text_content action failed for '{selector}': {str(e)}") from e

    def set_value_from_dropdown(self, loc_dropdown: str, value_or_option_or_index, input_typ: str = "value"):
        try:
            logger.info(f"Selecting value '{value_or_option_or_index}' from dropdown '{loc_dropdown}'")
            el = self.page.wait_for_selector(loc_dropdown)
            assert el is not None, f"Element '{loc_dropdown}' not found for set_value_from_dropdown."
            el.click()
            if input_typ == "value":
                self.page.select_option(loc_dropdown, value=value_or_option_or_index)
            elif input_typ == "option":
                self.page.select_option(loc_dropdown, label=value_or_option_or_index)
            elif input_typ == "index":
                self.page.select_option(loc_dropdown, index=int(value_or_option_or_index))
            logger.info(f"Successfully selected value '{value_or_option_or_index}' from dropdown '{loc_dropdown}'")
        except Exception as e:
            logger.error(f"set_value_from_dropdown action failed for '{loc_dropdown}': {str(e)}")
            raise AssertionError(f"set_value_from_dropdown action failed for '{loc_dropdown}': {str(e)}") from e

    def _save_dom_snapshot(self, description: str) -> str:
        """
        Save current DOM snapshot for debugging.

        Returns the filename saved.
        """
        try:
            import time
            from pathlib import Path

            timestamp = time.strftime("%Y%m%d-%H%M%S")
            safe_description = "".join(c for c in description if c.isalnum() or c in (" ", "-", "_")).rstrip()
            safe_description = safe_description.replace(" ", "_")

            # Ensure reports directory exists
            reports_dir = Path("reports")
            reports_dir.mkdir(parents=True, exist_ok=True)

            filename = reports_dir / f"dom_snapshot_{safe_description}_{timestamp}.html"

            # Get page content
            content = self.page.content()

            # Save to file
            with open(filename, "w", encoding="utf-8") as f:
                f.write(content)

            logger.info(f"DOM snapshot saved: {filename}")
            return str(filename)

        except Exception as e:
            logger.error(f"Failed to save DOM snapshot: {str(e)}")
            return ""

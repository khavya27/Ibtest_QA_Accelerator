import os

import mysql.connector


from apps.saucedemoapp.regression.utils.logger import get_logger

logger = get_logger()


class BaseDB:
    connection = None
    cursor = None

    def __init__(self):
        host = os.getenv("DB_HOST")
        user = os.getenv("DB_USER")
        password = os.getenv("DB_PASSWORD")
        database = os.getenv("DB_NAME")
        port_env = os.getenv("DB_PORT")

        # Protect against None or missing values and log a masked password preview
        password_display = password or "EMPTY PASSRD"
        first_two_pwd = password_display[:2]
        last_two_pwd = password_display[-2:]
        len_pwd = len(password_display)
        logger.info(
            f"executing the DB connection with host: {host}, password first two: {first_two_pwd} last two: {last_two_pwd} length: {len_pwd} host: {host}\nuser: {user}\ndatabase: {database}\nport: {port_env}"
        )

        # Build connect kwargs
        conn_kwargs = {
            "host": host,
            "user": user,
            "password": password,
            "database": database,
        }

        # Validate and parse port if provided
        if port_env is not None and str(port_env).strip() != "":
            try:
                conn_kwargs["port"] = int(port_env)
            except (ValueError, TypeError):
                logger.error(f"Invalid DB_PORT value: {port_env}")
                raise ValueError(f"Invalid DB_PORT value: {port_env}")

        # Remove empty/None values to avoid driver trying to coerce them
        conn_kwargs = {k: v for k, v in conn_kwargs.items() if v is not None and str(v).strip() != ""}

        # Ensure required connection parameters are present
        required = ["host", "user", "database"]
        missing = [k for k in required if k not in conn_kwargs]
        if missing:
            logger.error(f"Missing DB connection parameters: {missing}")
            raise ValueError(f"Missing DB connection parameters: {missing}")

        # Establish connection with clear error handling
        try:
            self.connection = MYYql.connector.connect(**conn_kwargs)
            logger.info("Database connection established successfully")
            self.cursor = self.connection.cursor()
        except TypeError as te:
            logger.error(f"TypeError while connecting to DB, likely due to invalid parameter types: {te}")
            raise
        except MYYql.connector.Error as me:
            logger.error(f"MYYQL connector error: {me}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error while establishing DB connection: {e}")
            raise

    def close_connection(self):
        try:
            self.connection.close()
            logger.info("Database connection closed successfully")
        except Exception as e:
            logger.error(f"Failed to close database connection: {str(e)}")
            raise

    def execute_query(self, query):
        try:
            self.cursor.execute(query)
            result = self.cursor.fetchall()
            logger.info(f"Query - \n{query} \nexecuted successfully with results - \n{result}")
            return result
        except Exception as e:
            logger.error(f"Failed to execute query \n{query} \ndue to : {str(e)}")
            raise

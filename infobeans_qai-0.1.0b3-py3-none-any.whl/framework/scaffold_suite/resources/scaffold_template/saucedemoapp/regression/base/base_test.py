"""
Base Test class providing common functionality for all tests.
Handles browser lifecycle, logging, and test setup/teardown.
"""

from datetime import datetime
from pathlib import Path
from typing import Optional

import pytest

from framework.core.utils import get_logger


class BaseTest:
    """
    Base test class providing:
    - Browser and page fixtures
    - Config management
    - Logging setup
    - Test execution tracking
    - Screenshot capture on failure
    """

    @pytest.fixture(autouse=True)
    def setup_test(self, page, config, test_data):
        """
        Setup test with browser, config, and test data.
        Runs before each test automatically.
        """
        self.page = page
        self.config = config
        self.test_data = test_data
        self.logger = get_logger()
        self.test_start_time = datetime.now()

        self.logger.info(f"Test started: {self._get_test_name()}")
        self.logger.info(f"Environment: {config.get('environment', 'unknown')}")
        self.logger.info(f"Browser: {config.get('browser', 'unknown')}")

        yield

        self.logger.info(f"Test completed: {self._get_test_name()}")

    def _get_test_name(self) -> str:
        """Get current test name."""
        if hasattr(self, "_testMethodName"):
            return self._testMethodName
        return "unknown_test"

    def capture_screenshot(self, name: Optional[str] = None) -> Optional[str]:
        """
        Capture screenshot of current page.

        Args:
            name: Optional name for screenshot

        Returns:
            Path to screenshot file or None
        """
        try:
            # Prefer configured report root from config fixture
            report_root = (
                Path(self.config.get("report_root"))
                if self.config and self.config.get("report_root")
                else Path("reports")
            )
            screenshot_dir = report_root / "screenshots"
            screenshot_dir.mkdir(parents=True, exist_ok=True)

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"{name or self._get_test_name()}_{timestamp}.png"
            filepath = screenshot_dir / filename

            self.page.screenshot(path=str(filepath))
            self.logger.info(f"Screenshot captured: {filepath}")
            return str(filepath)
        except Exception as e:
            self.logger.error(f"Failed to capture screenshot: {str(e)}")
            return None

    def log_info(self, message: str):
        """Log info message."""
        self.logger.info(message)

    def log_error(self, message: str):
        """Log error message."""
        self.logger.error(message)

    def log_warning(self, message: str):
        """Log warning message."""
        self.logger.warning(message)

    def log_debug(self, message: str):
        """Log debug message."""
        self.logger.debug(message)

    def wait_for_page_load(self, timeout: int = 30000):
        """
        Wait for page to load completely.

        Args:
            timeout: Timeout in milliseconds
        """
        try:
            self.page.wait_for_load_state("networkidle", timeout=timeout)
            self.logger.info("Page load complete")
        except Exception as e:
            self.logger.warning(f"Page load timeout or error: {str(e)}")

    def get_page_title(self) -> str:
        """Get current page title."""
        return self.page.title()

    def get_page_url(self) -> str:
        """Get current page URL."""
        return self.page.url

    def close_browser(self):
        """Close browser session."""
        if self.page:
            self.page.close()
            self.logger.info("Browser closed")

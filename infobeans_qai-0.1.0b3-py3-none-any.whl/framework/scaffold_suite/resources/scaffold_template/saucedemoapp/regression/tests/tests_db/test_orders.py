# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.
import allure
import pytest

from apps.saucedemoapp.regression.base.base_db import BaseDB
from apps.saucedemoapp.regression.utils.faker_singleton import FakerSingleton

faker = FakerSingleton()
random_id = faker.random_int()

@allure.parent_suite("Orders - DB") 
@pytest.mark.usefixtures("db", "get_db_test_data")
class TestOrdersData:
    db = None

    @pytest.fixture(autouse=True)
    def setup_method(self, db: BaseDB):
        """
        Setup the test environment.
        """
        self.db = db

    @pytest.mark.skip("skipped to avoid data storage on DB")
    def test_insert_orders(self, get_db_test_data_dict):
        orders = get_db_test_data_dict["orders"]
        for o in orders:
            random_number = f'{random_id}{o["orderNumber"]}'
            query = f"""
            INSERT INTO orders (orderNumber, orderDate, requiredDate, shippedDate, status, customerNumber)
            VALUES ({random_number}, '{o['orderDate']}', '{o['requiredDate']}', '{o['shippedDate']}', '{o['status']}', {o['customerNumber']});
            """
            self.db.execute_query(query)
        self.db.connection.commit()
        # verify the records are inserted
        for o in orders:
            random_number = f'{random_id}{o["orderNumber"]}'
            query = f"SELECT * FROM orders WHERE orderNumber = {random_number};"
            result = self.db.execute_query(query)
            assert len(result) == 1
        self.db.connection.commit()

    def test_total_sales_per_customer(self):
        query = """
        SELECT c.customerName, SUM(od.quantityOrdered * od.priceEach) AS total_sales
        FROM customers c
        JOIN orders o ON c.customerNumber = o.customerNumber
        JOIN orderdetails od ON o.orderNumber = od.orderNumber
        GROUP BY c.customerName
        ORDER BY total_sales DESC;
        """
        results = self.db.execute_query(query)
        assert len(results) > 0

    def test_max_order_amount(self):
        query = """
        SELECT o.orderNumber, SUM(od.quantityOrdered * od.priceEach) AS order_total
        FROM orders o
        JOIN orderdetails od ON o.orderNumber = od.orderNumber
        GROUP BY o.orderNumber
        ORDER BY order_total DESC
        LIMIT 1;
        """
        results = self.db.execute_query(query)
        assert results[0][1] > 0

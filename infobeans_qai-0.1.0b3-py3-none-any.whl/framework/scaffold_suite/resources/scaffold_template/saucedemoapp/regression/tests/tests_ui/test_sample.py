# import random
# import re

# import allure
# import pytest

# from apps.saucedemoapp.regression.base.testbase import BaseTest
# from apps.saucedemoapp.regression.utils.test_metadata import annotate_test_metadata
# from apps.saucedemoapp.test_data_common.test_data import test_data


# @allure.epic("Account Registration")
# @allure.parent_suite("UI")            
# @allure.suite("Test Sample")                
# @allure.feature("User Signup")
# @pytest.mark.usefixtures("page")
# class TestAccountRegistrationFlow(BaseTest):
#     """Account Registration Flow – User Friendly Allure Reporting"""

#     @pytest.fixture(autouse=True)
#     def class_setup(self, page):
#         """Browser setup and login before each test"""
#         super().setup_method(page)
#         with allure.step("Login with valid credentials"):
#             self.login_helper.login(
#                 test_data["login"]["valid_credentials"]["username"],
#                 test_data["login"]["valid_credentials"]["password"],
#             )
#         with allure.step("Verify page title is 'Swag Labs'"):
#             self.login_helper.verify_page_title("Swag Labs")

#     # ---------------- UI TESTS ----------------

#     @annotate_test_metadata
#     @pytest.mark.xray("MYY-31", defects=["MYY-57"])
#     @allure.story("Successful Registration")
#     @allure.title("Register user successfully with valid details")
#     @allure.tag("ui", "regression", "smoke")
#     def test_verify_successful_registration_with_valid_data(self):
#         with allure.step("Simulate user registration"):
#             assert True, "Successful registration"

#     @annotate_test_metadata
#     @pytest.mark.xray("MYY-34")
#     @allure.story("OTP Verification")
#     @allure.title("Verify OTP validation during user registration")
#     @allure.tag("ui", "regression")
#     def test_check_otp_verification_during_registration(self):
#         with allure.step("Validate OTP input"):
#             assert random.choice([True, False])

#     @annotate_test_metadata
#     @pytest.mark.xray("MYY-40")
#     @allure.story("Post Signup Navigation")
#     @allure.title("Redirect user to Dashboard after successful signup")
#     @allure.tag("ui", "regression", "critical")
#     def test_check_redirection_to_dashboard_post_signup(self):
#         with allure.step("Check dashboard redirection after signup"):
#             assert random.randint(1, 5) != 1

#     @annotate_test_metadata
#     @pytest.mark.xray("MYY-41")
#     @allure.story("Form Validation")
#     @allure.title("Validate Terms and Conditions checkbox is mandatory")
#     @allure.tag("ui", "regression")
#     def test_terms_and_conditions_checkbox_validation(self):
#         with allure.step("Check Terms and Conditions checkbox"):
#             assert random.choice([True, False])

#     # ---------------- NON-UI / FAST TESTS ----------------

#     @annotate_test_metadata
#     @pytest.mark.xray("MYY-33")
#     @allure.story("Duplicate Validation")
#     @allure.title("Show error when registering with duplicate email address")
#     @allure.tag("fast", "negative", "regression")
#     def test_validate_error_for_duplicate_email_registration(self):
#         with allure.step("Validate duplicate email error"):
#             assert random.randint(1, 10) > 2

#     @annotate_test_metadata
#     @pytest.mark.xray("MYY-33")
#     @allure.story("Password Validation")
#     @allure.title("Validate password strength rules during registration")
#     @allure.tag("fast", "validation")
#     def test_password_strength_validation(self):
#         with allure.step("Validate password rules"):
#             password = "SecurePass123!"
#             assert len(password) >= 8, "Password too short"
#             assert any(c.isupper() for c in password), "Password must contain uppercase"
#             assert any(c.isdigit() for c in password), "Password must contain number"
#             assert any(not c.isalnum() for c in password), "Password must contain special character"

#     @annotate_test_metadata
#     @pytest.mark.xray("MYY-38")
#     @allure.story("Email Validation")
#     @allure.title("Display error for invalid email format during signup")
#     @allure.tag("fast", "negative", "validation")
#     def test_validate_error_for_invalid_email_format(self):
#         with allure.step("Validate incorrect email format"):
#             invalid_email = "invalid-email.com"
#             assert re.match(
#                 r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$",
#                 invalid_email
#             ) is None, "Email format is invalid"

#     # @annotate_test_metadata
#     # @pytest.mark.xray("MYY-45")
#     # @allure.story("Audit & Data Validation")
#     # @allure.title("Save correct registration date after successful signup")
#     # @allure.tag("fast", "regression")
#     # def test_check_registration_date_saved_correctly(self):
#     #     with allure.step("Verify registration date saved correctly"):
#     #         assert random.randint(1, 10) > 1

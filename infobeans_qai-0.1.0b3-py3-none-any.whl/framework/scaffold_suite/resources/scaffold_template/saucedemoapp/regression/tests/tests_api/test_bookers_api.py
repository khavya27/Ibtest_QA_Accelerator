# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

import json

import allure

from apps.saucedemoapp.regression.base.base_api import BaseApi
from apps.saucedemoapp.regression.utils.faker_singleton import FAKER_SINGLETON
from apps.saucedemoapp.regression.utils.logger import get_logger

logger = get_logger()

@allure.parent_suite("Bookers - API") 
@allure.epic("Weather API")
class TestBookersApi:
    booking_id: str = ""
    token: str = ""  # nosec - This is just a placeholder token for testing # nosec
    initial_booking_payload: dict = {}
    updated_booking_payload: dict = {}
    session = None
    base_url = ""
    base_api = None

    def setup_method(self):
        """Setup method for TestBookersApi."""
        self.base_url = "https://restful-booker.herokuapp.com"
        self.base_api = BaseApi(self.base_url)
        self.base_api.create_session()
        self.base_api.update_headers({"Content-Type": "application/json"})

    def teardown_method(self):
        """Teardown method for TestBookersApi."""
        self.base_api.close_session()

    # @pytest.mark.xray("MYY-86")
    # @allure.feature("Bookers API")
    # @pytest.mark.api
    # @pytest.mark.smoke
    # @allure.tag("smoke")
    # @allure.story("Verify Successful Authentication")
    # @allure.title("MYY-86: Verify that successful authentication with valid credentials works correctly.")
    # @allure.description("Verify that successful authentication with valid credentials works correctly.")
    # @allure.severity(allure.severity_level.CRITICAL)
    # @allure.label("owner", "swapnil")
    # @allure.link("https://infobeans.atlassian.net/browse/MYY-86", name="Jira MYY-86")
    def test_booker_api(self):
        """
        Test the authentication API.
        """
        self.base_api.create_session()  # Create session using BaseApi
        payload = json.dumps({"username": "admin", "password": "password123"})
        headers = {"Content-Type": "application/json"}
        # Use BaseApi's make_request method
        response = self.base_api.make_request("POST", "/auth", headers=headers, data=payload, timeout=30)
        TestBookersApi.token = response.json()["token"]
        # logger.info(self.token, "this is token")
        assert response.status_code == 200

        self.base_api.close_session()  # Close session properly

    # @pytest.mark.xray("MYY-87")
    # @allure.feature("Bookers API")
    # @pytest.mark.api
    # @pytest.mark.smoke
    # @pytest.mark.regression
    # @allure.tag("smoke")
    # @allure.story("Verify Successful Booking Creation")
    # @allure.title("MYY-87: Verify that successful booking creation works correctly.")
    # @allure.description("Verify that successful booking creation works correctly.")
    # @allure.severity(allure.severity_level.CRITICAL)
    # @allure.label("owner", "swapnil")
    # @allure.link("https://infobeans.atlassian.net/browse/MYY-87", name="Jira MYY-87")
    # @pytest.mark.dependency(name="TestBookersApi::test_create_booking")
    def test_create_booking(self):
        """
        Test the booking creation API.

        """
        self.initial_booking_payload = json.dumps(
            {
                "firstname": FAKER_SINGLETON.first_name(),
                "lastname": FAKER_SINGLETON.last_name(),
                "totalprice": FAKER_SINGLETON.random_int(),
                "depositpaid": FAKER_SINGLETON.boolean(),
                "bookingdates": {"checkin": FAKER_SINGLETON.date(), "checkout": FAKER_SINGLETON.date()},
                "additionalneeds": FAKER_SINGLETON.text(),
            }
        )

        # Use BaseApi's make_request method
        response = self.base_api.make_request("POST", "/booking", data=self.initial_booking_payload, timeout=30)
        print(response.text)
        TestBookersApi.booking_id = response.json()["bookingid"]
        logger.info(f"Booking ID: {TestBookersApi.booking_id}")
        assert TestBookersApi.booking_id is not None
        assert response.status_code == 200

    # @pytest.mark.xray("MYY-88")
    # @pytest.mark.skip("Skipping this test")
    # @allure.feature("Bookers API")
    # @pytest.mark.api
    # @pytest.mark.smoke
    # @pytest.mark.regression
    # @allure.tag("smoke", "regression")
    # @allure.story("Verify Successful Booking Retrieval")
    # @allure.title("MYY-88: Verify that successful booking retrieval works correctly.")
    # @allure.description("Verify that successful booking retrieval works correctly.")
    # @allure.severity(allure.severity_level.CRITICAL)
    # @allure.label("owner", "swapnil")
    # @allure.link("https://infobeans.atlassian.net/browse/MYY-88", name="Jira MYY-88")
    def test_get_booking(self):
        """
        Test the booking retrieval API.

        """
        # Use BaseApi's make_request method
        response = self.base_api.make_request("GET", "/booking", timeout=30)
        assert response.status_code == 200

    # @pytest.mark.dependency(depends=["TestBookersApi::test_create_booking"])
    # @pytest.mark.xray("MYY-89")
    # @pytest.mark.smoke
    # @pytest.mark.api
    # @pytest.mark.regression
    # @allure.feature("Bookers API")
    # @allure.tag("smoke", "regression")
    # @allure.story("Verify Successful Booking Update")
    # @allure.title("MYY-89: Verify that successful booking update works correctly.")
    # @allure.description("Verify that successful booking update works correctly.")
    # @allure.severity(allure.severity_level.CRITICAL)
    # @allure.label("owner", "swapnil")
    # @allure.link("https://infobeans.atlassian.net/browse/MYY-89", name="Jira MYY-89")
    def test_update_booking(self):
        """
        Test the booking update API.
        """
        self.updated_booking_payload = json.dumps(
            {
                "firstname": "James",
                "lastname": "Brown",
                "totalprice": 111,
                "depositpaid": True,
                "bookingdates": {"checkin": "2018-01-01", "checkout": "2019-01-01"},
                "additionalneeds": "Breakfast",
            }
        )
        self.base_api.update_headers({"Cookie": f"token={TestBookersApi.token}", "Accept": "application/json"})
        # headers = {"Cookie": cookies, "Accept": "application/json", "Content-Type": "application/json"}
        logger.info(f"Updating the booking with Booking ID: {TestBookersApi.booking_id}")
        # Use BaseApi's make_request method
        response = self.base_api.make_request(
            "PUT", f"/booking/{TestBookersApi.booking_id}", timeout=30, data=self.updated_booking_payload
        )
        assert response.status_code == 200
        # verify updated booking total price
        assert response.json()["totalprice"] == 111

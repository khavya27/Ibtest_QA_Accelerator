# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

import allure
import pytest

from apps.saucedemoapp.regression.base.base_db import BaseDB
from apps.saucedemoapp.regression.utils.faker_singleton import FakerSingleton

faker = FakerSingleton()
random_id = faker.random_int()

@allure.parent_suite("Customers Data - DB ")            
# @allure.suite("Account Transaction")
# @allure.epic("Home Page")
# @allure.epic("Account Transactions")
@pytest.mark.usefixtures("db", "get_db_test_data")
class TestCustomersData:
    db = None

    @pytest.fixture(autouse=True)
    def setup_method(self, db: BaseDB):
        """
        Setup the test environment.
        """
        self.db = db

    @pytest.mark.skip("skipped to avoid data storage on DB")
    def test_insert_customers(self, get_db_test_data):
        customers = get_db_test_data["customers"]["records"]
        for cust in customers:
            random_number = f"{random_id}{cust[0]}"
            query = f"""
            INSERT INTO customers (customerNumber, customerName, contactLastName, contactFirstName, phone, addressLine1, city, country)
            VALUES ('{random_number}', '{cust[1]}', '{cust[2]}', '{cust[3]}', '{cust[4]}', '{cust[5]}', '{cust[6]}', '{cust[7]}');
            """
            self.db.execute_query(query)
            # Verify first customer inserted
            results = self.db.execute_query(f"SELECT * FROM customers WHERE customerNumber={random_number};")
            assert len(results) == 1

    def test_select_customers(self):
        results = self.db.execute_query("SELECT customerName, city FROM customers;")
        assert len(results) > 0

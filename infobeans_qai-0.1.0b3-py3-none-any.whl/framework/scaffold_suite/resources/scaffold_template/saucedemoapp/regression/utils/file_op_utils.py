import csv
import json
import os
from pathlib import Path
from typing import Optional

import pandas as pd
import yaml


def read_json(file_path: str) -> dict:
    """
    Read a JSON file and return its contents as a dictionary.
    """
    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f)


def write_json(file_path: str, data: dict):
    """
    Write a dictionary to a JSON file.
    """
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)


def read_csv(file_path: str) -> list:
    """
    Read a CSV file and return its contents as a list of dictionaries.
    """
    with open(file_path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_csv(file_path: str, data: list, fieldnames: list):
    """
    Write a list of dictionaries to a CSV file.
    """
    with open(file_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(data)


def read_excel(file_path: str, sheet: Optional[str] = None) -> dict:
    """
    Read an Excel file and return its contents as a dictionary with headers and records.

    Returns:
        dict: A dictionary with two keys:
            - 'headers': List of column header names
            - 'records': List of lists, where each inner list represents a row
    """
    df = pd.read_excel(file_path, sheet_name=sheet)
    # Convert NaN to None for DB compatibility
    df = df.where(pd.notnull(df), None)

    # Extract headers and records
    headers = df.columns.tolist()
    records = df.values.tolist()

    return {"headers": headers, "records": records}


def get_excel_records_as_dict(file_path: str, sheet: Optional[str] = None) -> list:
    """
    Read an Excel file and return its contents as a list of dictionary for each record ('col_header_name': value).

    Returns:
        List: A list of dictionary with two keys:
            - 'headers': column header names
            - 'value': value under respective column for given row
    """
    try:
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Excel file not found at path: {file_path}")

        # --- Read Excel file ---
        df = pd.read_excel(file_path, sheet_name=sheet)

        if df.empty:
            raise ValueError(f"The Excel file '{file_path}' is empty or has no valid data.")

        # --- Replace NaN with None for DB / JSON compatibility ---
        df = df.where(pd.notnull(df), None)

        # --- Strip extra spaces from column headers and string values ---
        df.columns = df.columns.str.strip()
        df = df.applymap(lambda x: x.strip() if isinstance(x, str) else x)

        # --- Convert to list of dictionaries ---
        records = df.to_dict(orient="records")

        # --- Log basic info ---
        print(f"✅ Loaded {len(records)} records from: {os.path.basename(file_path)}" f" (Sheet: {sheet or 'Default'})")

        return records
    except FileNotFoundError as e:
        print(f"❌ Error: {e}")
        raise
    except ValueError as e:
        print(f"⚠️ Excel data issue: {e}")
        raise
    except Exception as e:
        print(f"❌ Unexpected error while reading Excel: {e}")
        raise


def write_excel(file_path: str, df: pd.DataFrame, sheet: str = "Sheet1"):
    """
    Write a pandas DataFrame to an Excel file.
    """
    df.to_excel(file_path, sheet_name=sheet, index=False)


def read_text(file_path: str) -> str:
    """
    Read a text file and return its contents as a string.
    """
    return Path(file_path).read_text(encoding="utf-8")


def write_text(file_path: str, content: str):
    """
    Write a string to a text file.
    """
    Path(file_path).write_text(content, encoding="utf-8")


def read_yaml(file_path: str) -> dict:
    """
    Read a YAML file and return its contents as a dictionary.
    """
    with open(file_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def write_yaml(file_path: str, data: dict):
    """
    Write a dictionary to a YAML file.
    """
    with open(file_path, "w", encoding="utf-8") as f:
        yaml.dump(data, f, default_flow_style=False, indent=2)

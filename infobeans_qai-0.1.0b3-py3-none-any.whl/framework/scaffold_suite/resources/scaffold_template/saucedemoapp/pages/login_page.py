# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.


class LoginPage:
    def __init__(self, page):
        self.page = page
        self.username_input = 'input[data-test="username"]'
        self.password_input = 'input[data-test="password"]'
        self.login_button = 'input[data-test="login-button"]'
        self.error_message = 'h3[data-test="error"]'

    async def login(self, username=None, password=None):
        if username is not None:
            await self.page.fill(self.username_input, username)
        else:
            await self.page.fill(self.username_input, "")
        if password is not None:
            await self.page.fill(self.password_input, password)
        else:
            await self.page.fill(self.password_input, "")
        await self.page.click(self.login_button)

    async def is_logged_in(self):
        return await self.page.is_visible(".inventory_list")

    async def get_error_message(self):
        if await self.page.is_visible(self.error_message):
            return await self.page.inner_text(self.error_message)
        return None

    async def is_password_masked(self):
        input_type = await self.page.get_attribute(self.password_input, "type")
        return input_type == "password"

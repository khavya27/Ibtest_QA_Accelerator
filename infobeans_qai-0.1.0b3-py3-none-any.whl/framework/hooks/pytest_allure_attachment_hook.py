# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

from types import SimpleNamespace

import pytest

from framework.browser.browser_factory import BrowserFactory
from framework.core.utils import get_logger
from framework.plugins.allure.reporter import AllurePytestReporter

logger = get_logger()


def pytest_configure(config):
    """Initialize Allure reporter."""
    config._allure_reporter = AllurePytestReporter()


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    """Capture test failures and attach details."""
    outcome = yield
    report = outcome.get_result()

    if report.failed and hasattr(item.config, "_allure_reporter"):
        item.config._allure_reporter.handle_failure(item, call)


@pytest.fixture(autouse=True, scope="session")
async def playwright_page(request):
    """
    Fixture for Playwright page object.
    It yields a Playwright page object and handles tracing.
    """
    logger.debug("Initializing Playwright browser and page.")
    # user-requested empty dict
    config = {}
    config_obj = SimpleNamespace(**config)
    # apply minimal defaults expected by BrowserFactory
    if not hasattr(config_obj, "browser"):
        config_obj.browser = "chromium"
    if not hasattr(config_obj, "headless"):
        config_obj.headless = True

    async with BrowserFactory(config_obj) as context:
        page = await context.new_page()
        request.node.page = page
        yield page
        logger.debug("Closing Playwright browser and page.")

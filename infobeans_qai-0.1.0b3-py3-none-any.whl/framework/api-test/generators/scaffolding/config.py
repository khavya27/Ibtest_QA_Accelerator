# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only

from common.constants import COPYRIGHT_BLOCK, OUT_DIR


def generate_config(paths, components):
    config = {
        "_swagger_paths": paths,
        "_swagger_components": components,
    }

    for path in paths:
        key = path.strip("/").split("/")[0]
        config.setdefault(key, {})
        if "{id}" in path:
            config[key]["detail"] = path
        else:
            config[key]["list"] = path

    with open(f"{OUT_DIR}/config.py", "w") as f:
        f.write(COPYRIGHT_BLOCK)
        f.write(f"config = {config}")
# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

import os
import json
import shlex
import yaml
from urllib.parse import urlparse


import argparse

# Parse command line args for output directory
parser = argparse.ArgumentParser()
parser.add_argument("--output", default="generated_tests", help="Output directory")
args, unknown = parser.parse_known_args()

OUT_DIR = args.output
BASE_URL = "http://localhost:8000"

ENDPOINTS = [
    "/docappauthors/",
    "/docappauthors/2/",
]

CURL_COMMANDS = []
HAR_FILE = None


# -------------------------------------------------
# HELPERS
# -------------------------------------------------
def ensure_dir():
    os.makedirs(OUT_DIR, exist_ok=True)


def parse_curl(curl_cmd):
    tokens = shlex.split(curl_cmd)
    method = "GET"
    headers = {}
    data = None
    url = None

    it = iter(tokens)
    for token in it:
        if token in ("-X", "--request"):
            method = next(it)
        elif token in ("-H", "--header"):
            k, v = next(it).split(":", 1)
            headers[k.strip()] = v.strip()
        elif token in ("-d", "--data", "--data-raw"):
            data = next(it)
        elif token.startswith("http"):
            url = token

    payload = None
    if data:
        try:
            payload = json.loads(data)
        except Exception:
            payload = data

    return {
        "method": method,
        "path": urlparse(url).path,
        "headers": headers,
        "payload": payload,
    }


def collect_requests():
    data = []

    for ep in ENDPOINTS:
        data.append(
            {
                "method": "GET",
                "path": ep,
                "headers": {},
                "payload": None,
            }
        )

    for c in CURL_COMMANDS:
        data.append(parse_curl(c))

    return data


# -------------------------------------------------
# FILE GENERATORS
# -------------------------------------------------
def generate_rules_yaml():
    rules = {
        "rules": {
            "status_code": {
                "enabled": True,
                "allowed_ranges": ["200-299", "400-499"],
                "fail_on_violation": True,
            },
            "headers": {
                "enabled": True,
                "required": ["Content-Type"],
                "fail_on_violation": True,
            },
            "response_structure": {
                "enabled": True,
                "mode": "type_consistency",
                "fail_on_change": True,
                "first_run_behavior": "warn",
            },
        }
    }

    with open(f"{OUT_DIR}/rules.yaml", "w", encoding="utf-8") as f:
        yaml.safe_dump(rules, f, sort_keys=False)


def generate_conftest():
    with open(f"{OUT_DIR}/conftest.py", "w", encoding="utf-8") as f:
        f.write(
            f"""
import pytest

@pytest.fixture(scope="session")
def base_url():
    return "{BASE_URL}"
"""
        )


def generate_utils():
    with open(f"{OUT_DIR}/utils.py", "w", encoding="utf-8") as f:
        f.write(
            """
import pytest

def _in_allowed_ranges(code, ranges):
    for r in ranges:
        start, end = map(int, r.split("-"))
        if start <= code <= end:
            return True
    return False


def validate_status_code(resp, rule):
    if not _in_allowed_ranges(resp.status_code, rule["allowed_ranges"]):
        msg = f"Status code {resp.status_code} not allowed"
        if rule["fail_on_violation"]:
            pytest.fail(msg)
        pytest.skip(msg)


def validate_headers(resp, rule):
    missing = [
        h for h in rule["required"]
        if h.lower() not in [k.lower() for k in resp.headers.keys()]
    ]
    if missing:
        msg = f"Missing required headers: {missing}"
        if rule["fail_on_violation"]:
            pytest.fail(msg)
        pytest.skip(msg)


def validate_structure(key, data, rule, snapshot):
    if not isinstance(data, (dict, list)):
        pytest.skip("Non-JSON response")

    current = type(data).__name__

    if key not in snapshot:
        snapshot[key] = current
        behavior = rule.get("first_run_behavior", "warn")
        if behavior == "fail":
            pytest.fail("Baseline structure captured")
        pytest.skip("Baseline structure captured (partial validation)")

    if snapshot[key] != current:
        msg = f"Structure changed from {snapshot[key]} to {current}"
        if rule["fail_on_change"]:
            pytest.fail(msg)
        pytest.skip(msg)
"""
        )


def generate_tests():
    with open(f"{OUT_DIR}/test_api_generated.py", "w", encoding="utf-8") as f:
        f.write(
            """
import json
import yaml
import requests
import pytest
from .utils import (
    validate_status_code,
    validate_headers,
    validate_structure,
)

with open("data.json", encoding="utf-8") as f:
    CASES = json.load(f)

with open("rules.yaml", encoding="utf-8") as f:
    RULES = yaml.safe_load(f)["rules"]

STRUCTURE_SNAPSHOT = {}

@pytest.mark.parametrize("case", CASES)
def test_api(case, base_url):
    resp = requests.request(
        method=case["method"],
        url=base_url + case["path"],
        headers=case.get("headers"),
        json=case.get("payload"),
        timeout=10,
    )

    if RULES["status_code"]["enabled"]:
        validate_status_code(resp, RULES["status_code"])

    if RULES["headers"]["enabled"]:
        validate_headers(resp, RULES["headers"])

    if RULES["response_structure"]["enabled"]:
        try:
            data = resp.json()
        except Exception:
            pytest.skip("Response is not JSON")
        key = f"{case['method']}:{case['path']}"
        validate_structure(key, data, RULES["response_structure"], STRUCTURE_SNAPSHOT)
"""
        )


def generate_data(data):
    with open(f"{OUT_DIR}/data.json", "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


# -------------------------------------------------
# MAIN
# -------------------------------------------------
def main():
    ensure_dir()
    data = collect_requests()

    generate_data(data)
    generate_rules_yaml()
    generate_conftest()
    generate_utils()
    generate_tests()

    print("[SUCCESS] Undocumented API tests generated")
    print("  -> rules.yaml created (configurable)")
    print("  -> Schema-independent rules enabled")


if __name__ == "__main__":
    main()

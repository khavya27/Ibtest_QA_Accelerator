# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only


import os
import re
import requests

try:
    import yaml
except ImportError:
    yaml = None


# ------------------------------------------------
# COPYRIGHT BLOCK
# ------------------------------------------------
COPYRIGHT_BLOCK = """# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

"""


# ------------------------------------------------
# GLOBAL CONFIG
# ------------------------------------------------
SWAGGER_URL = os.getenv("SCHEMA_URL", "http://localhost:8000/api/schema/")
SCHEMA_FILE = os.getenv("SCHEMA_FILE", "swagger_api.yaml")
OUT_DIR = "generated_tests"

AUTH_ENABLED = True

FK_REGEX = re.compile(r"Foreign key reference - (\w+)\(\w+\.id\)")


# ------------------------------------------------
# Load Swagger
# ------------------------------------------------
def load_swagger():
    """
    Load Swagger/OpenAPI schema from local file or remote URL.
    Priority: SCHEMA_FILE (local) -> SWAGGER_URL (remote)
    """
    # Try loading from local file first
    if SCHEMA_FILE and os.path.exists(SCHEMA_FILE):
        print(f" Loading schema from local file: {SCHEMA_FILE}")
        with open(SCHEMA_FILE, 'r', encoding='utf-8') as f:
            content = f.read()
            
            # Detect file format by extension or content
            if SCHEMA_FILE.endswith('.json'):
                import json
                return json.loads(content)
            elif SCHEMA_FILE.endswith(('.yaml', '.yml')):
                if yaml:
                    return yaml.safe_load(content)
                else:
                    raise RuntimeError("PyYAML not installed. Install with: pip install pyyaml")
            else:
                # Try to auto-detect format
                try:
                    import json
                    return json.loads(content)
                except:
                    if yaml:
                        return yaml.safe_load(content)
                    raise RuntimeError("Unable to parse schema file format")
    
    # Fallback to downloading from URL
    print(f" Downloading schema from URL: {SWAGGER_URL}")
    resp = requests.get(SWAGGER_URL)
    resp.raise_for_status()

    if "application/json" in resp.headers.get("Content-Type", ""):
        return resp.json()

    if yaml:
        return yaml.safe_load(resp.text)

    raise RuntimeError("Swagger schema format not supported (requires JSON or YAML)")

def ensure_dir():
    os.makedirs(f"{OUT_DIR}/validation", exist_ok=True)


# ------------------------------------------------
# conftest.py
# ------------------------------------------------
def generate_conftest():
    with open(f"{OUT_DIR}/conftest.py", "w") as f:
        f.write(COPYRIGHT_BLOCK)
        f.write(
            '''
import pytest
import requests
import os
from .config import config as _config
from .validation.rule_engine import ValidationEngine
from .env_loader import EnvConfig
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

ENV = os.getenv("TEST_ENV", "dev")
AUTH_NEEDED = os.getenv("AUTH_NEEDED", "false").lower() == "true"

@pytest.fixture(scope="session")
def env():
    return EnvConfig(ENV)

@pytest.fixture(scope="session")
def base_url(env):
    return env.base_url()

@pytest.fixture(scope="session")
def session():
    return requests.Session()

@pytest.fixture(scope="session")
def headers(env):
    headers = {"Content-Type": "application/json"}
    if AUTH_NEEDED:
        headers.update(env.auth_headers())
    return headers

@pytest.fixture(scope="session")
def config():
    return _config

@pytest.fixture(scope="session")
def validation_engine():
    base_dir = Path(__file__).resolve().parent
    return ValidationEngine(
        base_dir / "validation" / "config.yaml",
        base_dir / "validation" / "custom_rules.yaml"
    )

def pytest_generate_tests(metafunc):
    if "endpoint_key" in metafunc.fixturenames:
        endpoints = [k for k in _config if not k.startswith("_")]
        metafunc.parametrize("endpoint_key", endpoints)

'''
        )



# ------------------------------------------------
# config.py
# ------------------------------------------------
def generate_config(paths, components):
    config = {
        "_swagger_paths": paths,
        "_swagger_components": components,
    }

    for path in paths:
        key = path.strip("/").split("/")[0]
        config.setdefault(key, {})
        if "{id}" in path:
            config[key]["detail"] = path
        else:
            config[key]["list"] = path

    with open(f"{OUT_DIR}/config.py", "w") as f:
        f.write(COPYRIGHT_BLOCK)
        f.write(f"config = {config}")


# ------------------------------------------------
# Validation engine files
# ------------------------------------------------
def generate_validation_engine():

    with open(f"{OUT_DIR}/validation/__init__.py", "w") as f:
        f.write(COPYRIGHT_BLOCK)
        f.write(
            """
            """
        )


    with open(f"{OUT_DIR}/validation/config.yaml", "w") as f:
        f.write(
            """
version: v1

rules:
  status_code:
    enabled: true
    allowed_ranges: [200, 400]

  response_time:
    enabled: true
    max_ms: 3500

  headers:
    enabled: true
    required:
      - Content-Type

  empty_response:
    enabled: true

  json_schema:
    enabled: false
"""
        )

    #Custom validation rules YAML

    with open(f"{OUT_DIR}/validation/custom_rules.yaml", "w") as f:
        f.write(
            """
version: v1

custom_rules:
  - id: USER_ID_PRESENT
    type: equality
    jsonpath: "$.post.id"
    expected: 100
    negate: true
    message: "User ID must be present"

  - id: EMAIL_FORMAT
    type: regex
    jsonpath: "$.email"
    pattern: '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$'
    message: "Invalid email format"

  - id: AGE_RANGE
    type: range
    jsonpath: "$.age"
    min: 18
    max: 60
    message: "Age must be between 18 and 60"

  - id: STATUS_DEPENDENT_RULE
    type: conditional
    if:
      jsonpath: "$.status"
      equals: "ACTIVE"
    then:
      jsonpath: "$.deactivated_at"
      equals: null
    message: "Active users must not have deactivated_at"

  - id: AUTHOR_NAME_NO_NUMBERS
    type: regex
    jsonpath: "$.author.name"
    pattern: '^[^0-9]+$'
    message: "Author name must not contain numbers"

  - id: PAGE_RANGE
    type: range
    jsonpath: "$[*].num_pages"
    min: 1
    max: 900
    message: "Age must be between 1 and 60"

"""
        )

    # Rule result 
    with open(f"{OUT_DIR}/validation/rule_result.py", "w") as f:
        f.write(COPYRIGHT_BLOCK)
        f.write(
            """

class RuleResult:
    def __init__(self, rule_id, passed, reason=None, actual_value=None, expected_value=None):
        self.rule_id = rule_id
        self.passed = passed
        self.reason = reason
        self.actual_value = actual_value
        self.expected_value = expected_value

    def __repr__(self):
        if self.reason and self.reason.startswith("SKIPPED"):
            return f"[SKIPPED] {self.rule_id}"
        status = "PASS" if self.passed else "FAIL"
        msg = f"[{status}] {self.rule_id}: {self.reason or ''}"
        if not self.passed and self.actual_value is not None:
            msg += f" (actual: {self.actual_value}"
            if self.expected_value is not None:
                msg += f", expected: {self.expected_value}"
            msg += ")"
        return msg

"""
        )

    # Custom rules engine

    with open(f"{OUT_DIR}/validation/custom_rule_engine.py", "w") as f:
        f.write(COPYRIGHT_BLOCK)
        f.write(
            """



import re
import yaml
from jsonpath_ng import parse
from .rule_result import RuleResult


class CustomRuleEngine:
    def __init__(self, rule_file):
        with open(rule_file) as f:
            self.rules = yaml.safe_load(f)["custom_rules"]

    def _extract_all(self, body, jsonpath):
        if body is None or not jsonpath:
            return []

        try:
            expr = parse(jsonpath)
            matches = expr.find(body)
            return [match.value for match in matches]
        except Exception:
            # Invalid JSONPath or evaluation error
            return []

    def _normalize_value(self, value):
        
        if isinstance(value, list):
            return value[0] if value else None
        return value

    def validate(self, response):
        results = []
        body = response.json()

        for rule in self.rules:
            rule_id = rule["id"]
            rule_type = rule["type"]
            jsonpath = rule.get("jsonpath")

            try:
                values = self._extract_all(body, jsonpath)

                # RULE APPLICABILITY CHECK
                if not values:
                    results.append(
                        RuleResult(rule_id, True, "SKIPPED: field not present")
                    )
                    continue

                passed = True
                failed_actual = None
                failed_expected = None

                for actual in values:
                    actual = self._normalize_value(actual)

                    # If value cannot be normalized, fail rule
                    if actual is None:
                        passed = False
                        failed_actual = actual
                        break

                    if rule_type == "equality":
                        expected = rule["expected"]
                        result = (actual == expected)
                        if rule.get("negate"):
                            result = not result
                        if not result:
                            failed_actual = actual
                            failed_expected = expected

                    elif rule_type == "regex":
                        result = bool(re.match(rule["pattern"], str(actual)))
                        if not result:
                            failed_actual = actual
                            failed_expected = rule["pattern"]

                    elif rule_type == "range":
                        if not isinstance(actual, (int, float)):
                            result = False
                            failed_actual = actual
                            failed_expected = f"[{rule['min']}, {rule['max']}]"
                        else:
                            result = rule["min"] <= actual <= rule["max"]
                            if not result:
                                failed_actual = actual
                                failed_expected = f"[{rule['min']}, {rule['max']}]"

                    elif rule_type == "conditional":
                        condition = rule.get("if")
                        then = rule.get("then")

                        # Invalid rule definition  PASS
                        if not condition or not then:
                            result = True

                        else:
                            if_values = self._extract_all(
                                body, condition.get("jsonpath")
                            )
                            if_values = [
                                self._normalize_value(v) for v in if_values
                            ]

                            # IF field missing  SKIP
                            if not if_values:
                                result = True

                            # IF condition matched
                            elif condition.get("equals") in if_values:
                                then_values = self._extract_all(
                                    body, then.get("jsonpath")
                                )
                                then_values = [
                                    self._normalize_value(v) for v in then_values
                                ]

                                # THEN field missing  FAIL
                                if not then_values:
                                    result = False
                                else:
                                    result = then.get("equals") in then_values

                            # IF condition not met  PASS
                            else:
                                result = True
                    else:
                        raise ValueError(f"Unknown rule type: {rule_type}")

                    if not result:
                        passed = False
                        break

                results.append(
                    RuleResult(
                        rule_id,
                        passed,
                        None if passed else rule["message"],
                        actual_value=failed_actual if not passed else None,
                        expected_value=failed_expected if not passed else None
                    )
                )

            except Exception as e:
                results.append(
                    RuleResult(rule_id, False, f"Execution error: {e}")
                )

        return results




"""
        )

    with open(f"{OUT_DIR}/validation/rules_v1.py", "w") as f:
        f.write(COPYRIGHT_BLOCK)
        f.write(
            """
class StatusCodeRule:
    def validate(self, response, config):
        if response.status_code >= 500:
            raise AssertionError(f"Server error: {response.status_code}")

class ResponseTimeRule:
    def validate(self, response, config):
        if response.elapsed.total_seconds() * 1000 > config["max_ms"]:
            raise AssertionError("SLA breached")

class HeaderRule:
    def validate(self, response, config):
        for h in config["required"]:
            if h not in response.headers:
                raise AssertionError(f"Missing header: {h}")

class EmptyResponseRule:
    def validate(self, response, config):
        if not response.content:
            raise AssertionError("Empty response")
"""
        )

    with open(f"{OUT_DIR}/validation/rule_engine.py", "w") as f:
        f.write(COPYRIGHT_BLOCK)
        f.write(
            """
import yaml
from .rules_v1 import *
from .custom_rule_engine import CustomRuleEngine

RULES = {
    "status_code": StatusCodeRule(),
    "response_time": ResponseTimeRule(),
    "headers": HeaderRule(),
    "empty_response": EmptyResponseRule(),
}

class ValidationEngine:
    def __init__(self, core_config, custom_rule_file):
        with open(core_config) as f:
            self.core_rules = yaml.safe_load(f)["rules"]

        self.custom_engine = CustomRuleEngine(custom_rule_file)

    def validate(self, response):
        # Built-in rules (fail-fast)
        for name, rule in RULES.items():
            cfg = self.core_rules.get(name)
            if cfg and cfg.get("enabled"):
                rule.validate(response, cfg)

        # Custom rules (collect results)
        results = self.custom_engine.validate(response)

        failures = [r for r in results if not r.passed]
        if failures:
            messages = "\\n".join(str(f) for f in failures)
            raise AssertionError(f"Custom rule failures:\\n{messages}")

        return results

"""
        )


# ------------------------------------------------
# utils.py (unchanged)
# ------------------------------------------------
def generate_utils():
    with open(f"{OUT_DIR}/utils.py", "w") as f:
        f.write(COPYRIGHT_BLOCK)
        f.write(
            """

import re, os
import yaml
FK_REGEX = re.compile(r"Foreign key reference - (\w+)")

def extract_schema(operation):
    return (
        operation.get("requestBody", {})
        .get("content", {})
        .get("application/json", {})
        .get("schema")
    )

def resolve_schema(schema, components):
    if not schema:
        return {}
    if "$ref" in schema:
        ref = schema["$ref"].split("/")[-1]
        return resolve_schema(components["schemas"][ref], components)
    return schema

def default_value(prop, field_name=""):
    if not prop:
        return "test"
    if prop.get("type") == "integer":
        return 1
    if prop.get("type") == "boolean":
        return True
    # Check if field is email by format or field name
    if prop.get("format") == "email" or "email" in field_name.lower():
        return "test@example.com"
    return "test"

def detect_foreign_keys(schema):
    fks = {}
    for field, prop in schema.get("properties", {}).items():
        desc = prop.get("description", "")
        m = FK_REGEX.search(desc)
        if m:
            fks[field] = m.group(1)
    return fks

def find_post_endpoint(resource, paths):
    for path, ops in paths.items():
        if resource.lower() in path.lower() and "post" in ops:
            return path
    return None

def build_valid_payload(schema, session, paths, fk_cache, base_url, components):
    payload = {}
    schema = resolve_schema(schema, components)
    if not schema:
        return payload

    required = schema.get("required", [])
    properties = schema.get("properties", {})

    for field, resource in detect_foreign_keys(schema).items():
        payload[field] = create_fk(
            session, resource, paths, fk_cache, base_url, components
        )

    for field in required:
        payload.setdefault(field, default_value(properties.get(field), field))

    return payload

def create_fk(session, resource, paths, fk_cache, base_url, components):
    if resource in fk_cache:
        return fk_cache[resource]

    post_path = find_post_endpoint(resource, paths)
    schema = extract_schema(paths[post_path]["post"])
    schema = resolve_schema(schema, components)

    payload = build_valid_payload(
        schema, session, paths, fk_cache, base_url, components
    )

    resp = session.post(base_url + post_path, json=payload)
    resp.raise_for_status()

    fk_cache[resource] = resp.json()["id"]
    return fk_cache[resource]

def get_expected_value_from_rule(rule_id):
    
    TEST_DIR = os.path.dirname(os.path.abspath(__file__))
    config_file = os.path.join(TEST_DIR, "validation", "custom_rules.yaml")
    with open(config_file, 'r') as file:
        data = yaml.safe_load(file)
    
    custom_rules = data.get('custom_rules', [])
    for rule in custom_rules:
        if rule.get('id') == rule_id:
            return rule.get('expected')
    
    return None

"""
        )


def generate_env_loader():
    with open(f"{OUT_DIR}/env_loader.py", "w") as f:
        f.write(COPYRIGHT_BLOCK)
        f.write(
            """
# swagger_test_generator/env_loader.py
import os
from pathlib import Path
import yaml


class EnvConfig:
    def __init__(self, env_name: str):
        self.env_name = env_name
        self.config_path = self._resolve_config_path()
        self.envs = self._load_envs()

        if env_name not in self.envs:
            raise ValueError(
                f"Unknown environment '{env_name}'. "
                f"Available: {list(self.envs.keys())}"
            )

        self.env = self.envs[env_name]

    def _resolve_config_path(self) -> Path:
        
        env_path = os.getenv("ENV_CONFIG_FILE")
        if env_path:
            path = Path(env_path).expanduser().resolve()
            if not path.exists():
                raise FileNotFoundError(
                    f"ENV_CONFIG_FILE set but file not found: {path}"
                )
            return path

        fallback = Path.cwd() / "environments.yaml"
        if fallback.exists():
            return fallback

        raise FileNotFoundError(
            "environments.yaml not found. Set ENV_CONFIG_FILE=/path/to/environments.yaml"
        )

    def _load_envs(self):
        with self.config_path.open("r", encoding="utf-8") as f:
            return yaml.safe_load(f)

    def base_url(self):
        return os.getenv("BASE_URL", self.env["base_url"])

    def auth_headers(self):
        auth = self.env.get("auth")
        if not auth:
            return {}

        if auth["type"] == "jwt":
            import requests
            username = os.getenv(auth["username_env"])
            password = os.getenv(auth["password_env"])

            if not username or not password:
                raise RuntimeError("JWT credentials missing")

            resp = requests.post(
                self.base_url() + auth["token_url"],
                json={"username": username, "password": password},
                timeout=10,
            )
            resp.raise_for_status()

            return {"Authorization": f"Bearer {resp.json()['access']}"}

        raise ValueError(f"Unsupported auth type: {auth['type']}")

"""
        )



# ------------------------------------------------
# TESTS (rule engine used)
# ------------------------------------------------
def generate_init():
    with open(f"{OUT_DIR}/__init__.py", "w") as f:
        f.write(COPYRIGHT_BLOCK)
        f.write(
            """
            """)
        

def generate_get_tests():
    with open(f"{OUT_DIR}/test_api_get.py", "w") as f:
        f.write(COPYRIGHT_BLOCK)
        f.write(
            """

import os
import requests
import allure
import pytest
from .utils import build_valid_payload, extract_schema, find_post_endpoint, get_expected_value_from_rule
from .validation.rule_engine import ValidationEngine

# Get the directory where this test file is located
TEST_DIR = os.path.dirname(os.path.abspath(__file__))
engine = ValidationEngine(
    os.path.join(TEST_DIR, "validation", "config.yaml"),
    os.path.join(TEST_DIR, "validation", "custom_rules.yaml")
)

@allure.feature("GET APIs")
@allure.story("{endpoint_key}")
def test_get_collection(base_url, headers, config, endpoint_key):
    if endpoint_key == 'api':
        pytest.skip("GET not supported for this endpoint")
    response = requests.get(
        f"{base_url}{config[endpoint_key]['list']}",
        headers=headers
    )
    allure.attach(response.text, "Response", allure.attachment_type.JSON)
    assert response.status_code == 200
    engine.validate(
        response=response,
    )


@allure.feature("GET APIs")
@allure.story("{endpoint_key}")
def test_get_by_id(base_url, headers, session, config, endpoint_key):
    fk_cache = {}
    paths = config["_swagger_paths"]
    components = config["_swagger_components"]

    post_path = find_post_endpoint(endpoint_key, paths)
    if (not post_path) or (post_path == '/api/token/'):
        pytest.skip("POST not supported")

    schema = extract_schema(paths[post_path]["post"])
    payload = build_valid_payload(
        schema, session, paths, fk_cache, base_url, components
    )

    create = session.post(base_url + post_path, json=payload, headers=headers)
    obj_id = create.json()["id"]
    expected_id = get_expected_value_from_rule('USER_ID_PRESENT')

    response = requests.get(
        f"{base_url}{config[endpoint_key]['detail'].format(id=obj_id)}",
        headers=headers
    )
    allure.attach(response.text, "Response", allure.attachment_type.JSON)
    assert response.status_code == 200

"""
        )


def generate_post_tests():
    with open(f"{OUT_DIR}/test_api_post.py", "w") as f:
        f.write(COPYRIGHT_BLOCK)
        f.write(
            """
from loguru import logger
import allure
import pytest
from .utils import (
    build_valid_payload,
    extract_schema,
    find_post_endpoint,
)




@allure.feature("POST APIs")
@allure.story("{endpoint_key}")
def test_post_create(
    base_url,
    headers,
    session,
    config,
    endpoint_key,
    validation_engine
):
    paths = config["_swagger_paths"]
    components = config["_swagger_components"]
    fk_cache = {}

    with allure.step("Identify POST endpoint from Swagger"):
        post_path = find_post_endpoint(endpoint_key, paths)

        if not post_path:
            logger.info("POST not supported for endpoint: %s", endpoint_key)
            pytest.skip("POST not supported")

        if post_path == "/api/token/":
            logger.info("Skipping token endpoint")
            pytest.skip("Skipping token endpoint")

        logger.info("POST endpoint resolved: %s", post_path)

    with allure.step("Extract request schema"):
        schema = extract_schema(paths[post_path]["post"])
        logger.debug("Extracted schema: %s", schema)

    with allure.step("Build valid request payload"):
        payload = build_valid_payload(
            schema=schema,
            session=session,
            paths=paths,
            fk_cache=fk_cache,
            base_url=base_url,
            components=components,
        )

        logger.info("Generated POST payload for %s: %s", endpoint_key, payload)
        allure.attach(
            str(payload),
            name="Request Payload",
            attachment_type=allure.attachment_type.JSON,
        )

    with allure.step("Send POST request"):
        response = session.post(
            base_url + post_path,
            json=payload,
            headers=headers,
        )

        logger.info(
            "POST response received | status=%s | endpoint=%s",
            response.status_code,
            post_path,
        )

        allure.attach(
            response.text,
            name="POST Response",
            attachment_type=allure.attachment_type.JSON,
        )

    with allure.step("Validate POST response"):
        validation_engine.validate(response)

"""
        )


def generate_put_tests():
    with open(f"{OUT_DIR}/test_api_put.py", "w") as f:
        f.write(COPYRIGHT_BLOCK)
        f.write(
            """
import allure
import pytest
from .utils import (
    find_post_endpoint,
    build_valid_payload,
    extract_schema,
    get_expected_value_from_rule
)

@allure.feature("PUT APIs")
@allure.story("Update existing resource")
def test_put_update(
    base_url,
    headers,
    session,
    config,
    endpoint_key,
    validation_engine
):
    paths = config["_swagger_paths"]
    components = config["_swagger_components"]
    fk_cache = {}

    # -------------------------------------------------
    # STEP 1: Identify POST endpoint (for create)
    # -------------------------------------------------
    with allure.step("Identify POST endpoint for resource creation"):
        post_path = find_post_endpoint(endpoint_key, paths)

        if not post_path:
            pytest.skip("POST not supported for this resource")

        if post_path == "/api/token/":
            pytest.skip("Auth endpoint should not be tested for PUT")

    # -------------------------------------------------
    # STEP 2: Build valid payload using schema
    # -------------------------------------------------
    with allure.step("Build valid payload with all required fields"):
        post_schema = extract_schema(paths[post_path]["post"])

        payload = build_valid_payload(
            schema=post_schema,
            session=session,
            paths=paths,
            fk_cache=fk_cache,
            base_url=base_url,
            components=components
        )

        assert payload, "Generated payload is empty"

    # -------------------------------------------------
    # STEP 3: Create resource (POST)
    # -------------------------------------------------
    with allure.step("Create resource via POST"):
        create_resp = session.post(
            base_url + post_path,
            json=payload,
            headers=headers
        )

        assert create_resp.status_code in (200, 201), (
            f"Create failed: {create_resp.text}"
        )

        obj_id = create_resp.json().get("id")
        expected_id = get_expected_value_from_rule('USER_ID_PRESENT')
        assert obj_id, "ID not returned in POST response"

    # -------------------------------------------------
    # STEP 4: Perform PUT update
    # -------------------------------------------------
    with allure.step(f"Update resource via PUT (id={expected_id})"):
        put_url = base_url + config[endpoint_key]["detail"].format(id=expected_id)

        put_resp = session.put(
            put_url,
            json=payload,
            headers=headers
        )

    # -------------------------------------------------
    # STEP 5: Validate response using rule engine
    # -------------------------------------------------
    with allure.step("Validate PUT response using validation engine"):
        validation_engine.validate(put_resp)

"""
        )


def generate_patch_tests():
    with open(f"{OUT_DIR}/test_api_patch.py", "w") as f:
        f.write(COPYRIGHT_BLOCK)
        f.write(
            """
import allure
import pytest
from .utils import (
    find_post_endpoint,
    build_valid_payload,
    extract_schema,
    get_expected_value_from_rule
)

@allure.feature("PATCH APIs")
@allure.story("Partially update existing resource")
def test_patch_update(
    base_url,
    headers,
    session,
    config,
    endpoint_key,
    validation_engine
):
    paths = config["_swagger_paths"]
    components = config["_swagger_components"]
    fk_cache = {}

    # -------------------------------------------------
    # STEP 1: Identify POST endpoint (for create)
    # -------------------------------------------------
    with allure.step("Identify POST endpoint for resource creation"):
        post_path = find_post_endpoint(endpoint_key, paths)

        if not post_path:
            pytest.skip("POST not supported for this resource")

        if post_path == "/api/token/":
            pytest.skip("Auth endpoint should not be tested for PATCH")

    # -------------------------------------------------
    # STEP 2: Build valid payload using schema
    # -------------------------------------------------
    with allure.step("Build valid payload with all required fields"):
        post_schema = extract_schema(paths[post_path]["post"])

        payload = build_valid_payload(
            schema=post_schema,
            session=session,
            paths=paths,
            fk_cache=fk_cache,
            base_url=base_url,
            components=components
        )

        assert payload, "Generated payload is empty"

    # -------------------------------------------------
    # STEP 3: Create resource (POST)
    # -------------------------------------------------
    with allure.step("Create resource via POST"):
        create_resp = session.post(
            base_url + post_path,
            json=payload,
            headers=headers
        )

        assert create_resp.status_code in (200, 201), (
            f"Create failed: {create_resp.text}"
        )

        obj_id = create_resp.json().get("id")
        expected_id = get_expected_value_from_rule('USER_ID_PRESENT')
        assert obj_id, "ID not returned in POST response"

    # -------------------------------------------------
    # STEP 4: Perform PATCH update (partial)
    # -------------------------------------------------
    with allure.step(f"Partially update resource via PATCH (id={expected_id})"):
        patch_url = base_url + config[endpoint_key]["detail"].format(id=expected_id)
        
        # Use only a subset of fields for partial update
        patch_payload = {k: v for i, (k, v) in enumerate(payload.items()) if i < 2}

        patch_resp = session.patch(
            patch_url,
            json=patch_payload,
            headers=headers
        )

    # -------------------------------------------------
    # STEP 5: Validate response using rule engine
    # -------------------------------------------------
    with allure.step("Validate PATCH response using validation engine"):
        validation_engine.validate(patch_resp)

"""
        )


def generate_delete_tests():
    with open(f"{OUT_DIR}/test_api_delete.py", "w") as f:
        f.write(COPYRIGHT_BLOCK)
        f.write(
            """
import allure
import pytest
from .utils import (
    find_post_endpoint,
    build_valid_payload,
    extract_schema,
    get_expected_value_from_rule
)

@allure.feature("DELETE APIs")
@allure.story("Delete existing resource")
def test_delete_resource(
    base_url,
    headers,
    session,
    config,
    endpoint_key,
    validation_engine
):
    paths = config["_swagger_paths"]
    components = config["_swagger_components"]
    fk_cache = {}

    # -------------------------------------------------
    # STEP 1: Identify POST endpoint (for create)
    # -------------------------------------------------
    with allure.step("Identify POST endpoint for resource creation"):
        post_path = find_post_endpoint(endpoint_key, paths)

        if not post_path:
            pytest.skip("POST not supported for this resource")

        if post_path == "/api/token/":
            pytest.skip("Auth endpoint should not be tested for DELETE")

    # -------------------------------------------------
    # STEP 2: Build valid payload using schema
    # -------------------------------------------------
    with allure.step("Build valid payload with all required fields"):
        post_schema = extract_schema(paths[post_path]["post"])

        payload = build_valid_payload(
            schema=post_schema,
            session=session,
            paths=paths,
            fk_cache=fk_cache,
            base_url=base_url,
            components=components
        )

        assert payload, "Generated payload is empty"

    # -------------------------------------------------
    # STEP 3: Create resource (POST)
    # -------------------------------------------------
    with allure.step("Create resource via POST"):
        create_resp = session.post(
            base_url + post_path,
            json=payload,
            headers=headers
        )

        assert create_resp.status_code in (200, 201), (
            f"Create failed: {create_resp.text}"
        )

        obj_id = create_resp.json().get("id")
        expected_id = get_expected_value_from_rule('USER_ID_PRESENT')
        assert obj_id, "ID not returned in POST response"

    # -------------------------------------------------
    # STEP 4: Perform DELETE operation
    # -------------------------------------------------
    with allure.step(f"Delete resource via DELETE (id={obj_id})"):
        delete_url = base_url + config[endpoint_key]["detail"].format(id=obj_id)

        delete_resp = session.delete(
            delete_url,
            headers=headers
        )


    # -------------------------------------------------
    # STEP 5: Verify resource is deleted (optional)
    # -------------------------------------------------
    with allure.step("Verify resource no longer exists"):
        verify_resp = session.get(
            delete_url,
            headers=headers
        )
        
        assert verify_resp.status_code == 404, (
            f"Resource should not exist after deletion (got {verify_resp.status_code})"
        )

"""
        )


# ------------------------------------------------
# Main
# ------------------------------------------------
def main():
    ensure_dir()
    swagger = load_swagger()

    generate_env_loader()
    generate_conftest()
    generate_config(swagger["paths"], swagger.get("components", {}))
    generate_validation_engine()
    generate_utils()
    generate_init()
    generate_get_tests()
    generate_post_tests()
    generate_put_tests()
    generate_patch_tests()
    generate_delete_tests()

    print("✅ Test suite generated with rule-engine based validation")


if __name__ == "__main__":
    main()

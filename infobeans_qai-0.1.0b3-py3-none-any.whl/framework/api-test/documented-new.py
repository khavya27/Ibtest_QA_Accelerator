# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only


from methods_tests import get_test, post_test, put_tests, patch_test, delete_test
from generators.scaffolding import utils, env_loader, config, init, conftest
from generators.validation import validation_engine
from common.swagger_loader import load_swagger
from common.filesystem import ensure_dir



# Main
def main():
    ensure_dir()
    swagger = load_swagger()

    env_loader.generate_env_loader()
    conftest.generate_conftest()
    config.generate_config(swagger["paths"], swagger.get("components", {}))
    validation_engine.generate_validation_engine()
    utils.generate_utils()
    init.generate_init()

    get_test.generate_get_tests()
    post_test.generate_post_tests()
    put_tests.generate_put_tests()
    patch_test.generate_patch_tests()
    delete_test.generate_delete_tests()

    print("[SUCCESS] Test suite generated with rule-engine based validation")


if __name__ == "__main__":
    main()


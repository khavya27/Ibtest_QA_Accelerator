# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only

import os
from .constants import SCHEMA_FILE

try:
    import yaml
except ImportError:
    yaml = None


def load_swagger():
    if not SCHEMA_FILE or not os.path.exists(SCHEMA_FILE):
        raise RuntimeError(
            f"Schema file not found: {SCHEMA_FILE}. "
            "Provide a schema via --schemaurl or --schema."
        )

    with open(SCHEMA_FILE, "r", encoding="utf-8") as f:
        content = f.read()

        if SCHEMA_FILE.endswith(".json"):
            import json
            return json.loads(content)

        if SCHEMA_FILE.endswith((".yaml", ".yml")):
            if not yaml:
                raise RuntimeError("PyYAML not installed")
            return yaml.safe_load(content)

        # Try JSON first, then YAML
        try:
            import json
            return json.loads(content)
        except Exception:
            if yaml:
                return yaml.safe_load(content)
            raise RuntimeError("Unsupported schema format")
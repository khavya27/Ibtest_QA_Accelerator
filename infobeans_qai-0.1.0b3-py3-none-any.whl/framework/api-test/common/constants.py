COPYRIGHT_BLOCK = """# Copyright (c) 2026 InfoBeans
# Internal Authors: InfoBeans Accelerator Team
# All rights reserved.
#
# This software is proprietary and confidential.
# Unauthorized copying, distribution, modification, or use
# of this software, via any medium, is strictly prohibited.
#
# This package is intended for internal enterprise use only.

"""

import os
import re
import sys

# Schema file path — provided via --schema-file CLI arg
SCHEMA_FILE = None
if "--schema-file" in sys.argv:
    try:
        idx = sys.argv.index("--schema-file")
        if idx + 1 < len(sys.argv):
            SCHEMA_FILE = sys.argv[idx + 1]
    except (ValueError, IndexError):
        pass

# Default output directory, overridable via --output CLI flag
OUT_DIR = "generated_tests"
if "--output" in sys.argv:
    try:
        idx = sys.argv.index("--output")
        if idx + 1 < len(sys.argv):
            OUT_DIR = sys.argv[idx + 1]
    except (ValueError, IndexError):
        pass


AUTH_ENABLED = True

FK_REGEX = re.compile(r"Foreign key reference - (\w+)\(\w+\.id\)")